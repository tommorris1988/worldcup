# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_commentmeta`
#

DROP TABLE IF EXISTS `worldcup_commentmeta`;


#
# Table structure of table `worldcup_commentmeta`
#

CREATE TABLE `worldcup_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_commentmeta (0 records)
#

#
# End of data contents of table worldcup_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_comments`
#

DROP TABLE IF EXISTS `worldcup_comments`;


#
# Table structure of table `worldcup_comments`
#

CREATE TABLE `worldcup_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_comments (1 records)
#
 
INSERT INTO `worldcup_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2014-06-02 10:45:45', '2014-06-02 10:45:45', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table worldcup_comments
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_links`
#

DROP TABLE IF EXISTS `worldcup_links`;


#
# Table structure of table `worldcup_links`
#

CREATE TABLE `worldcup_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_links (0 records)
#

#
# End of data contents of table worldcup_links
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_options`
#

DROP TABLE IF EXISTS `worldcup_options`;


#
# Table structure of table `worldcup_options`
#

CREATE TABLE `worldcup_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_options (136 records)
#
 
INSERT INTO `worldcup_options` VALUES (1, 'siteurl', 'http://localhost:8888/worldcup', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (2, 'blogname', 'itskickingoff', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (3, 'blogdescription', 'Just another WordPress site', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (5, 'admin_email', 'tom@fiascodesign.co.uk', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (20, 'default_pingback_flag', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (21, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (22, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (23, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (24, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (25, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (26, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (27, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (28, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (29, 'hack_file', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (30, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (31, 'moderation_keys', '', 'no') ; 
INSERT INTO `worldcup_options` VALUES (32, 'active_plugins', 'a:10:{i:0;s:27:"acf-gallery/acf-gallery.php";i:1;s:29:"acf-repeater/acf-repeater.php";i:2;s:35:"admin-menu-tree-page-view/index.php";i:3;s:30:"advanced-custom-fields/acf.php";i:4;s:39:"backup-with-restore/backupwordpress.php";i:5;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:6;s:47:"fitvids-for-wordpress/fitvids-for-wordpress.php";i:7;s:27:"mail-subscribe-list/sml.php";i:8;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:9;s:24:"wordpress-seo/wp-seo.php";}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (33, 'home', 'http://localhost:8888/worldcup', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `worldcup_options` VALUES (41, 'template', 'Foundation', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (42, 'stylesheet', 'Foundation', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `worldcup_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (49, 'db_version', '27916', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (52, 'blog_public', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (82, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `worldcup_options` VALUES (83, 'timezone_string', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (88, 'initial_db_version', '27916', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (89, 'worldcup_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:5:{i:0;s:14:"recent-posts-2";i:1;s:17:"recent-comments-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (96, 'cron', 'a:8:{i:1401750000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}i:1401792374;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1401802627;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1401823380;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1401835549;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1401836400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1402592407;a:1:{s:19:"publish_future_post";a:1:{s:32:"adcb9b75260590ff6058773ddcb9ddd6";a:2:{s:8:"schedule";b:0;s:4:"args";a:1:{i:0;i:4;}}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (98, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:58:"http://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:58:"http://downloads.wordpress.org/release/wordpress-3.9.1.zip";s:10:"no_content";s:69:"http://downloads.wordpress.org/release/wordpress-3.9.1-no-content.zip";s:11:"new_bundled";s:70:"http://downloads.wordpress.org/release/wordpress-3.9.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.9.1";s:7:"version";s:5:"3.9.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1401792815;s:15:"version_checked";s:5:"3.9.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (105, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1401792820;s:7:"checked";a:1:{s:10:"Foundation";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (107, '_site_transient_timeout_browser_f548fd0e09e226e838827c4d467bdb9a', '1402310762', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (109, '_site_transient_browser_f548fd0e09e226e838827c4d467bdb9a', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"29.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (112, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (113, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1401749167', 'no') ; 
INSERT INTO `worldcup_options` VALUES (114, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/?v=4.0-alpha-20140529";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.9.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/05/wordpress-3-9-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/05/wordpress-3-9-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 08 May 2014 18:40:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3241";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:385:"After three weeks and more than 9 million downloads of WordPress 3.9, we&#8217;re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3077:"<p>After three weeks and more than 9 million downloads of <a title="WordPress 3.9 “Smith”" href="http://wordpress.org/news/2014/04/smith/">WordPress 3.9</a>, we&#8217;re pleased to announce that WordPress 3.9.1 is now available.</p>
<p>This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We&#8217;ve also made some improvements to the new audio/video playlists feature and made some adjustments to improve performance. For a full list of changes, consult the <a href="https://core.trac.wordpress.org/query?milestone=3.9.1">list of tickets</a> and the <a href="https://core.trac.wordpress.org/log/branches/3.9?rev=28353&amp;stop_rev=28154">changelog</a>.</p>
<p>If you are one of the millions already running WordPress 3.9, we&#8217;ve started rolling out automatic background updates for 3.9.1. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.9.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.9.1: <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/jupiterwise">Corey McKrill</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/imath">imath</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/m_i_n">m_i_n</a>, <a href="http://profiles.wordpress.org/clorith">Marius Jensen</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinić</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, and <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/05/wordpress-3-9-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.9 “Smith”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2014/04/smith/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2014/04/smith/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 16 Apr 2014 18:33:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3154";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:411:"Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist Jimmy Smith, is available for download or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love. A smoother media editing experience Improved visual editing The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:23291:"<p>Version 3.9 of WordPress, named &#8220;Smith&#8221; in honor of jazz organist <a href="http://en.wikipedia.org/wiki/Jimmy_Smith_(musician)">Jimmy Smith</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features a number of refinements that we hope you&#8217;ll love.</p>
<embed src="//v0.wordpress.com/player.swf?v=1.03" type="application/x-shockwave-flash" width="640" height="360" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true" flashvars="guid=sAiXhCfV&amp;isDynamicSeeking=true" title=""></embed>
<h2 class="about-headline-callout" style="text-align: center">A smoother media editing experience</h2>
<div>
<p><img class="alignright wp-image-3168" src="//wordpress.org/news/files/2014/04/editor1-300x233.jpg" alt="editor" width="228" height="177" /></p>
<h3>Improved visual editing</h3>
<p>The updated visual editor has improved speed, accessibility, and mobile support. You can paste into the visual editor from your word processor without wasting time to clean up messy styling. (Yeah, we’re talking about you, Microsoft Word.)</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3170" src="//wordpress.org/news/files/2014/04/image1-300x233.jpg" alt="image" width="228" height="178" /></p>
<h3>Edit images easily</h3>
<p>With quicker access to crop and rotation tools, it’s now much easier to edit your images while editing posts. You can also scale images directly in the editor to find just the right fit.</p>
</div>
<div style="clear: both"></div>
<div>
<p><img class="alignright wp-image-3187" src="//wordpress.org/news/files/2014/04/dragdrop1-300x233.jpg" alt="dragdrop" width="228" height="178" /></p>
<h3>Drag and drop your images</h3>
<p>Uploading your images is easier than ever. Just grab them from your desktop and drop them in the editor.</p>
</div>
<div style="clear: both"></div>
<hr />
<h2 style="text-align: center">Gallery previews</h2>
<p><img class="aligncenter size-full wp-image-3169" src="//wordpress.org/news/files/2014/04/gallery1.jpg" alt="gallery" width="980" height="550" /></p>
<p>Galleries display a beautiful grid of images right in the editor, just like they do in your published post.</p>
<hr />
<h2 style="text-align: center">Do more with audio and video</h2>

<a href=\'http://wordpress.org/news/files/2014/04/AintMisbehavin.mp3\'>Ain\'t Misbehavin\'</a>
<a href=\'http://wordpress.org/news/files/2014/04/DavenportBlues.mp3\'>Davenport Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/JellyRollMorton-BuddyBoldensBlues.mp3\'>Buddy Bolden\'s Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/Johnny_Hodges_Orchestra-Squaty_Roo-1941.mp3\'>Squaty Roo</a>
<a href=\'http://wordpress.org/news/files/2014/04/Louisiana_Five-Dixie_Blues-1919.mp3\'>Dixie Blues</a>
<a href=\'http://wordpress.org/news/files/2014/04/WolverineBlues.mp3\'>Wolverine Blues</a>

<p>Images have galleries; now we’ve added simple audio and video playlists, so you can showcase your music and clips.</p>
<hr />
<h2 style="text-align: center">Live widget and header previews</h2>
<div style="width: 692px; max-width: 100%;" class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-3154-1" width="692" height="448" preload="metadata" controls="controls"><source type="video/mp4" src="//wordpress.org/news/files/2014/04/widgets.mp4?_=1" /><a href="//wordpress.org/news/files/2014/04/widgets.mp4">//wordpress.org/news/files/2014/04/widgets.mp4</a></video></div>
<p>Add, edit, and rearrange your site’s widgets right in the theme customizer. No “save and surprise” — preview your changes live and only save them when you’re ready.</p>
<p>The improved header image tool also lets you upload, crop, and manage headers while customizing your theme.</p>
<hr />
<h2 style="text-align: center">Stunning new theme browser</h2>
<p><img class="aligncenter size-full wp-image-3172" src="//wordpress.org/news/files/2014/04/theme1.jpg" alt="theme" width="1003" height="558" /><br />
Looking for a new theme should be easy and fun. Lose yourself in the boundless supply of free WordPress.org themes with the beautiful new theme browser.</p>
<hr />
<h2 style="text-align: center">The Crew</h2>
<p>This release was led by <a href="http://nacin.com/">Andrew Nacin</a> and <a href="http://www.getsource.net/">Mike Schroder</a>, with the help of these fine individuals. There are 267 contributors with props in this release, a new high:</p>
<p><a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="http://profiles.wordpress.org/adelval">adelval</a>, <a href="http://profiles.wordpress.org/ajay">Ajay</a>, <a href="http://profiles.wordpress.org/akeda">Akeda Bagus</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="http://profiles.wordpress.org/aliso">Alison Barrett</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/rarst">Andrey "Rarst" Savchenko</a>, <a href="http://profiles.wordpress.org/andykeith">Andy Keith</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/toszcze">Bartosz Romanowski</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/bcworkz">bcworkz</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bigdawggi">bigdawggi</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bramd">bramd</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brasofilo">brasofilo</a>, <a href="http://profiles.wordpress.org/bravokeyl">bravokeyl</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/cgaffga">cgaffga</a>, <a href="http://profiles.wordpress.org/chiragswadia">Chirag Swadia</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/ehg">Chris Blower</a>, <a href="http://profiles.wordpress.org/cmmarslender">Chris Marslender</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisscott">Chris Scott</a>, <a href="http://profiles.wordpress.org/chriseverson">chriseverson</a>, <a href="http://profiles.wordpress.org/chrisguitarguy">chrisguitarguy</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/ciantic">ciantic</a>, <a href="http://profiles.wordpress.org/antorome">Comparativa de Bancos</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/cramdesign">cramdesign</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/eightface">Dave Kellam (eightface)</a>, <a href="http://profiles.wordpress.org/dpe415">DaveE</a>, <a href="http://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="http://profiles.wordpress.org/davidanderson">David Anderson</a>, <a href="http://profiles.wordpress.org/davidmarichal">David Marichal</a>, <a href="http://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/eatingrules">eatingrules</a>, <a href="http://profiles.wordpress.org/plocha">edik</a>, <a href="http://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evarlese">Erica Varlese</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ejdanderson">Evan Anderson</a>, <a href="http://profiles.wordpress.org/fahmiadib">Fahmi Adib</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/genkisan">genkisan</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/grahamarmfield">Graham Armfield</a>, <a href="http://profiles.wordpress.org/vancoder">Grant Mangham</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky (@tivnet)</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="http://profiles.wordpress.org/ippetkov">ippetkov</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jackreichert">Jack Reichert</a>, <a href="http://profiles.wordpress.org/_jameslee">jameslee</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/jaycc">JayCC</a>, <a href="http://profiles.wordpress.org/jeffsebring">Jeff Sebring</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jesin">Jesin A</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jnielsendotnet">jnielsendotnet</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/johnregan3">John Regan</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/shelob9">Josh Pollock</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/jstraitiff">jstraitiff</a>, <a href="http://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="http://profiles.wordpress.org/kopepasah">Justin Kopepasah</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/kasparsd">Kaspars</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kerikae">kerikae</a>, <a href="http://profiles.wordpress.org/kworthington">Kevin Worthington</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/klihelp">klihelp</a>, <a href="http://profiles.wordpress.org/knutsp">Knut Sparhell</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lkwdwrd">lkwdwrd</a>, <a href="http://profiles.wordpress.org/lpointet">lpointet</a>, <a href="http://profiles.wordpress.org/ldebrouwer">Luc De Brouwer</a>, <a href="http://profiles.wordpress.org/spmlucas">Lucas Karpiuk</a>, <a href="http://profiles.wordpress.org/mark8barnes">Mark Barnes</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/marventus">Marventus</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt (Thomas) Miklic</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/mattonomics">mattonomics</a>, <a href="http://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/mcadwell">mcadwell</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/meloniq">meloniq</a>, <a href="http://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/mcsf">Miguel Fonseca</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikemanger">Mike Manger</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/mikecorkum">mikecorkum</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mor10">Morten Rand-Hendriksen</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/nendeb55">nendeb55</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nicolealleyinteractivecom">Nicole Arnold</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nivijah">Nivi Jah</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nunomorgadinho">Nuno Morgadinho</a>, <a href="http://profiles.wordpress.org/olivm">olivM</a>, <a href="http://profiles.wordpress.org/jbkkd">Omer Korner</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/oso96_2000">oso96_2000</a>, <a href="http://profiles.wordpress.org/patricknami">patricknami</a>, <a href="http://profiles.wordpress.org/pbearne">Paul Bearne</a>, <a href="http://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="http://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/prettyboymp">prettyboymp</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/ramonchiara">ramonchiara</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rhyswynne">Rhys Wynne</a>, <a href="http://profiles.wordpress.org/ricardocorreia">Ricardo Correia</a>, <a href="http://profiles.wordpress.org/theorboman">Richard Sweeney</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/richard2222">richard2222</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/robmiller">robmiller</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/romaimperator">romaimperator</a>, <a href="http://profiles.wordpress.org/roothorick">roothorick</a>, <a href="http://profiles.wordpress.org/ruudjoyo">ruud@joyo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood (Otto)</a>, <a href="http://profiles.wordpress.org/sandyr">Sandeep</a>, <a href="http://profiles.wordpress.org/scottlee">Scott Lee</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/greglone">ScreenfeedFr</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/sdasse">sdasse</a>, <a href="http://profiles.wordpress.org/bootsz">Sean Butze</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/nessworthy">Sean Nessworthy</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shahpranaf">shahpranaf</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sonjanyc">sonjanyc</a>, <a href="http://profiles.wordpress.org/spencerfinnell">Spencer Finnell</a>, <a href="http://profiles.wordpress.org/piontkowski">Spencer Piontkowski</a>, <a href="http://profiles.wordpress.org/stephcook22">stephcook22</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/sbruner">Steve Bruner</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tanner-m">Tanner Moushey</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tbrams">tbrams</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/willmot">Tom Willmot</a>, <a href="http://profiles.wordpress.org/topher1kenobe">Topher</a>, <a href="http://profiles.wordpress.org/topquarky">topquarky</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/toru">Toru</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/umeshsingla">Umesh Kumar</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, <a href="http://profiles.wordpress.org/varunagw">VarunAgw</a>, <a href="http://profiles.wordpress.org/wawco">wawco</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wokamoto">wokamoto</a>, <a href="http://profiles.wordpress.org/xsonic">xsonic</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>, <a href="http://profiles.wordpress.org/zbtirrell">Zach Tirrell</a>, and <a href="http://profiles.wordpress.org/vanillalounge">Ze Fontainhas</a>. Also thanks to <a href="http://michaelpick.wordpress.com/">Michael Pick</a> for producing the release video.</p>
<p>If you want to follow along or help out, check out <a href="http://make.wordpress.org/">Make WordPress</a> and our <a href="http://make.wordpress.org/core/">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.0!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2014/04/smith/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.9 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Apr 2014 09:47:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3151";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:356:"The second release candidate for WordPress 3.9 is now available for testing. If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the first release candidate, and those changes are all helpfully summarized in our weekly post on the development blog. Probably the biggest fixes are to live [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2273:"<p>The second release candidate for WordPress 3.9 is now available for testing.</p>
<p>If you haven&#8217;t tested 3.9 yet, you&#8217;re running out of time! We made about five dozen changes since the <a title="WordPress 3.9 Release Candidate" href="//wordpress.org/news/2014/04/wordpress-3-9-release-candidate/">first release candidate</a>, and those changes are all helpfully summarized <a href="//make.wordpress.org/core/?p=10237">in our weekly post</a> on the development blog. Probably the biggest fixes are to live widget previews and the new theme browser, along with some extra TinyMCE compatibility and some RTL fixes.</p>
<p><strong>Plugin authors:</strong> Could you test your plugins against 3.9, and if they&#8217;re compatible, make sure they are marked as tested up to 3.9? It only takes a few minutes and this really helps make launch easier. Be sure to follow along the core development blog; we&#8217;ve been posting <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example: <a href="//make.wordpress.org/core/2014/04/15/html5-galleries-captions-in-wordpress-3-9/">HTML5</a>, <a href="//make.wordpress.org/core/2014/04/14/symlinked-plugins-in-wordpress-3-9/">symlinks</a>, <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">MySQL</a>, <a href="//make.wordpress.org/core/2014/04/11/plupload-2-x-in-wordpress-3-9/">Plupload</a>.)</p>
<p>To test WordPress 3.9 RC2, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC2.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the nearly complete About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and also check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><em>This is for testing,</em><br />
<em>so not recommended for<br />
production sites—yet.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.3 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Apr 2014 19:29:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3145";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"WordPress 3.8.3 is now available to fix a small but unfortunate bug in the WordPress 3.8.2 security release. The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2339:"<p>WordPress 3.8.3 is now available to fix a small but unfortunate bug in the <a title="WordPress 3.8.2 Security Release" href="http://wordpress.org/news/2014/04/wordpress-3-8-2/">WordPress 3.8.2 security release</a>.</p>
<p>The &#8220;Quick Draft&#8221; tool on the dashboard screen was broken in the 3.8.2 update. If you tried to use it, your draft would disappear and it wouldn&#8217;t save. While we doubt anyone was writing a novella using this tool, <em>any</em> loss of content is unacceptable to us.</p>
<p>We recognize how much trust you place in us to safeguard your content, and we take this responsibility very seriously. We&#8217;re sorry we let you down.</p>
<p>We&#8217;ve all lost words we&#8217;ve written before, like an email thanks to a cat on the keyboard or a term paper to a blue screen of death. Over the last few WordPress releases, we&#8217;ve made a number of improvements to features like autosaves and revisions. With revisions, an old edit can always be restored. We&#8217;re trying our hardest to save your content somewhere even if your power goes out or your browser crashes. We even monitor your internet connection and prevent you from hitting that &#8220;Publish&#8221; button at the exact moment the coffee shop Wi-Fi has a hiccup.</p>
<p>It&#8217;s <em>possible</em> that the quick draft you lost last week is still in the database, and just hidden from view. As an added complication, these &#8220;discarded drafts&#8221; normally get deleted after seven days, and it&#8217;s already been six days since the release. If we were able to rescue your draft, you&#8217;ll see it on the &#8220;All Posts&#8221; screen after you update to 3.8.3. (We&#8217;ll also be pushing 3.8.3 out as a background update, so you may just see a draft appear.)</p>
<p>So, if you tried to jot down a quick idea last week, I hope WordPress has recovered it for you. Maybe it&#8217;ll turn into that novella.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.3</a> or click &#8220;Update Now&#8221; on Dashboard → Updates.</p>
<p><em>This affected version 3.7.2 as well, so we&#8217;re pushing a 3.7.3 to these installs, but we&#8217;d encourage you to update to the latest and greatest.</em></p>
<hr />
<p><em>Now for some good news:<br />
WordPress 3.9 is near.<br />
Expect it this week</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.9 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 21:05:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3129";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"As teased earlier, the first release candidate for WordPress 3.9 is now available for testing! We hope to ship WordPress 3.9 next week, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.) To test WordPress 3.9 [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2967:"<p><a href="//wordpress.org/news/2014/04/wordpress-3-8-2/">As teased earlier</a>, the first release candidate for WordPress 3.9 is now available for testing!</p>
<p>We hope to ship WordPress 3.9 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.9 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>To test WordPress 3.9 RC1, try the <a href="//wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="//wordpress.org/wordpress-3.9-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what’s new in WordPress 3.9, visit the work-in-progress About screen in your dashboard (<strong><img src="//i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" alt="" width="16" height="16" /> → About</strong> in the toolbar) and check out <a title="WordPress 3.9 Beta 1" href="//wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 post</a>.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="//wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="//core.trac.wordpress.org/report/5">find them here</a>.</p>
<p><strong>If you&#8217;re a plugin author</strong>, there are two important changes in particular to be aware of:</p>
<ul>
<li>TinyMCE received a major update, to version 4.0. Any editor plugins written for TinyMCE 3.x might require some updates. (If things broke, we&#8217;d like to hear about them so we can make adjustments.) For more, see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">migration guide</a> and <a href="http://www.tinymce.com/wiki.php/api4:index">API documentation</a>, and the notes on the <a href="//make.wordpress.org/core/2014/01/18/tinymce-4-0-is-in-core/">core development blog</a>.</li>
<li>WordPress 3.9 now uses the MySQLi Improved extension for sites running PHP 5.5. Any plugins that made direct calls to <code>mysql_*</code> functions will experience some problems on these sites. For more information, see the notes on the <a href="//make.wordpress.org/core/2014/04/07/mysql-in-wordpress-3-9/">core development blog</a>.</li>
</ul>
<p>Be sure to follow along the core development blog, where we will be continuing to post <a href="//make.wordpress.org/core/tag/3-9-dev-notes/">notes for developers for 3.9</a>. (For example, read <a href="//make.wordpress.org/core/2014/03/27/masonry-in-wordpress-3-9/">this</a> if you are using Masonry in your theme.) And please, please update your plugin&#8217;s <em>Tested up to</em> version in the readme to 3.9 before April 16.</p>
<p><em>Release candidate<br />
This haiku&#8217;s the easy one<br />
3.9 is near</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2014/04/wordpress-3-9-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"WordPress 3.8.2 Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/04/wordpress-3-8-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/04/wordpress-3-8-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Apr 2014 19:04:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3124";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:355:"WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately. This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by Jon Cave of the WordPress [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2272:"<p>WordPress 3.8.2 is now available. This is an important security release for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This releases fixes a weakness that could let an attacker force their way into your site by forging authentication cookies. This was discovered and fixed by <a href="http://joncave.co.uk/">Jon Cave</a> of the WordPress security team.</p>
<p>It also contains a fix to prevent a user with the Contributor role from improperly publishing posts. Reported by <a href="http://edik.ch/">edik</a>.</p>
<p>This release also fixes nine bugs and contains three other security hardening changes:</p>
<ul>
<li>Pass along additional information when processing pingbacks to help hosts identify potentially abusive requests.</li>
<li>Fix a low-impact SQL injection by trusted users. Reported by <a href="http://www.dxw.com/">Tom Adams</a> of dxw.</li>
<li>Prevent possible cross-domain scripting through Plupload, the third-party library WordPress uses for uploading files. Reported by <a href="http://szgru.website.pl/">Szymon Gruszecki</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these security issues directly to our security team. For more information on all of the changes, see the <a href="http://codex.wordpress.org/Version_3.8.2">release notes</a> or consult <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=28057&amp;stop_rev=27024">the list of changes</a>.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Sites that support automatic background updates will be updated to WordPress 3.8.2 within 12 hours. If you are still on WordPress 3.7.1, you will be updated to 3.7.2, which contains the same security fixes as 3.8.2. We don&#8217;t support older versions, so please update to 3.8.2 for the latest and greatest.</p>
<p>Already testing WordPress 3.9? The first release candidate is <a href="https://wordpress.org/wordpress-3.9-RC1.zip">now available</a> (zip) and it contains these security fixes. Look for a full announcement later today; we expect to release 3.9 next week.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/04/wordpress-3-8-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 29 Mar 2014 13:15:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3106";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"The third (and maybe last) beta of WordPress 3.9 is now available for download. Beta 3 includes more than 200 changes, including: New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out. UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2668:"<p>The third (and maybe last) beta of WordPress 3.9 is now available for download.</p>
<p>Beta 3 includes more than 200 <a href="https://core.trac.wordpress.org/log?rev=27850&amp;stop_rev=27639&amp;limit=300">changes</a>, including:</p>
<ul>
<li>New features like live widget previews and the new theme installer are now more ready for prime time, so check &#8216;em out.</li>
<li>UI refinements when editing images and when working with media in the editor. We&#8217;ve also brought back some of the advanced display settings for images.</li>
<li>If you want to test out audio and video playlists, the links will appear in the media manager once you&#8217;ve uploaded an audio or video file.</li>
<li>For theme developers, we&#8217;ve added HTML5 caption support (<a class="reopened ticket" title="task (blessed): HTML5 captions (reopened)" href="https://core.trac.wordpress.org/ticket/26642">#26642</a>) to match the new gallery support (<a class="closed ticket" title="enhancement: HTML5 Galleries (closed: fixed)" href="https://core.trac.wordpress.org/ticket/26697">#26697</a>).</li>
<li>The formatting function that turns straight quotes into smart quotes (among other things) underwent some changes to drastically speed it up, so let us know if you see anything weird.</li>
</ul>
<p><strong>We need your help</strong>. We&#8217;re still aiming for an April release, which means the next week will be critical for identifying and squashing bugs. If you&#8217;re just joining us, please see <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a> for what to look out for.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums, where friendly moderators are standing by. <b>Plugin developers</b><strong>,</strong> if you haven&#8217;t tested WordPress 3.9 yet, now is the time — and be sure to update the &#8220;tested up to&#8221; version for your plugins so they&#8217;re listed as compatible with 3.9.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta3.zip">download the beta here</a> (zip).</p>
<p><em>WordPress 3.9<br />
Let&#8217;s make the date official<br />
It&#8217;s April 16</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Mar 2014 05:01:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3101";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:309:"WordPress 3.9 Beta 2 is now available for testing! We&#8217;ve made more than a hundred changes since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to the Beta 1 announcement post. Some of the changes in [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1901:"<p>WordPress 3.9 Beta 2 is now available for testing!</p>
<p>We&#8217;ve made more than a hundred <a href="https://core.trac.wordpress.org/log?rev=27639&amp;stop_rev=27500&amp;limit=200">changes</a> since Beta 1, but we still need your help if we&#8217;re going to hit our goal of an April release. For what to look out for, please head on over to <a href="https://wordpress.org/news/2014/03/wordpress-3-9-beta-1/">the Beta 1 announcement post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Rendering of embedded audio and video players directly in the visual editor.</li>
<li>Visual and functional improvements to the editor, the media manager, and theme installer.</li>
<li>Various bug fixes to TinyMCE, the software behind the visual editor.</li>
<li>Lots of fixes to widget management in the theme customizer.</li>
</ul>
<p>As always,<strong> if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta2.zip">download the beta here</a> (zip).</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.9 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 11 Mar 2014 13:42:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3083";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:329:"I&#8217;m excited to announce that the first beta of WordPress 3.9 is now available for testing. WordPress 3.9 is due out next month &#8212; but in order to hit that goal, we need your help testing all of the goodies we&#8217;ve added: We updated TinyMCE, the software powering the visual editor, to the latest version. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:6065:"<p>I&#8217;m excited to announce that the <strong>first beta of WordPress 3.9</strong> is now available for testing.</p>
<p>WordPress 3.9 is due out next month &#8212; but in order to hit that goal, <strong>we need your help</strong> testing all of the goodies we&#8217;ve added:</p>
<ul>
<li>We updated TinyMCE, the software powering the visual editor, to the latest version. Be on the lookout for cleaner markup. Also try the new paste handling &#8212; if you paste in a block of text from Microsoft Word, for example, it will no longer come out terrible. (The &#8220;Paste from Word&#8221; button you probably never noticed has been removed.) It&#8217;s possible some plugins that added stuff to the visual editor (like a new toolbar button) no longer work, so we&#8217;d like to hear about them (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>). (And be sure to <a href="http://wordpress.org/support/">open a support thread</a> for the plugin author.)</li>
<li>We&#8217;ve added <strong>widget management to live previews</strong> (the customizer). Please test editing, adding, and rearranging widgets! (<a href="https://core.trac.wordpress.org/ticket/27112">#27112</a>) We&#8217;ve also added the ability to upload, crop, and manage header images, without needing to leave the preview. (<a href="https://core.trac.wordpress.org/ticket/21785">#21785</a>)</li>
<li>We brought 3.8&#8242;s beautiful new theme browsing experience to the <strong>theme installer</strong>. Check it out! (<a title="View ticket" href="https://core.trac.wordpress.org/ticket/27055">#27055</a>)</li>
<li><strong>Galleries</strong> now receive a live preview in the editor. Upload some photos and insert a gallery to see this in action. (<a href="https://core.trac.wordpress.org/ticket/26959">#26959</a>)</li>
<li>You can now <strong>drag-and-drop</strong> images directly onto the editor to upload them. It can be a bit finicky, so try it and help us work out the kinks. (<a href="https://core.trac.wordpress.org/ticket/19845">#19845</a>)</li>
<li>Some things got improved around <strong>editing images</strong>. It&#8217;s a lot easier to make changes to an image after you insert it into a post (<a class="closed" title="View ticket" href="https://core.trac.wordpress.org/ticket/24409">#24409</a>) and you no longer get kicked to a new window when you need to crop or rotate an image (<a href="https://core.trac.wordpress.org/ticket/21811">#21811</a>).</li>
<li>New <strong>audio/video playlists</strong>. Upload a few audio or video files to test these. (<a href="https://core.trac.wordpress.org/ticket/26631">#26631</a>)</li>
</ul>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. We&#8217;d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href="https://make.wordpress.org/core/reports/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/tickets/major">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.9">everything we’ve fixed</a> so far.</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 3.9, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.9-beta1.zip">download the beta here</a> (zip).</p>
<hr />
<p><strong>DEVELOPERS!</strong> Hello! There&#8217;s lots for you, too.</p>
<p><strong>Please test your plugins and themes!</strong> There&#8217;s a lot of great stuff under the hood in 3.9 and we hope to blog a bit about them in the coming days. If you haven&#8217;t been reading the awesome <a href="http://make.wordpress.org/core/tag/week-in-core/">weekly summaries</a> on the <a href="http://make.wordpress.org/core/">main core development blog</a>, that&#8217;s a great place to start. (You should definitely follow that blog.) For now, here are some things to watch out for when testing:</p>
<ul>
<li>The <strong>load process in multisite</strong> got rewritten. If you notice any issues with your network, see <a href="https://core.trac.wordpress.org/ticket/27003">#27003</a>.</li>
<li>We now use the <strong>MySQL Improved (mysqli) database extension</strong> if you&#8217;re running a recent version of PHP (<a href="https://core.trac.wordpress.org/ticket/21663">#21663</a>). Please test your plugins and see that everything works well, and please make sure you&#8217;re not calling <code>mysql_*</code> functions directly.</li>
<li><strong>Autosave</strong> was refactored, so if you see any issues related to autosaving, heartbeat, etc., let us know (<a href="https://core.trac.wordpress.org/ticket/25272">#25272</a>).</li>
<li>Library updates, in particular Backbone 1.1 and Underscore 1.6 (<a href="https://core.trac.wordpress.org/ticket/26799">#26799</a>). Also Masonry 3 (<a href="https://core.trac.wordpress.org/ticket/25351">#25351</a>), PHPMailer (<a href="https://core.trac.wordpress.org/ticket/25560">#25560</a>), Plupload (<a href="https://core.trac.wordpress.org/ticket/25663">#25663</a>), and TinyMCE (<a href="https://core.trac.wordpress.org/ticket/24067">#24067</a>).</li>
<li>TinyMCE 4.0 is a <em>major</em> update. Please see TinyMCE&#8217;s <a href="http://www.tinymce.com/wiki.php/Tutorial:Migration_guide_from_3.x">upgrade guide</a> and our <a href="https://core.trac.wordpress.org/ticket/24067">implementation ticket</a> for more. If you have any questions or problems, please <a href="http://wordpress.org/support/forum/alphabeta">open a thread in the support forums</a>.</li>
</ul>
<p>Happy testing!</p>
<p><em><em>Lots of improvements<br />
Little things go a long way</em><br />
Please test beta one<br />
</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2014/03/wordpress-3-9-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.8.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2014/01/wordpress-3-8-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2014/01/wordpress-3-8-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jan 2014 20:37:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=3063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:358:"After six weeks and more than 9.3 million downloads of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available. Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3809:"<p>After six weeks and more than <a href="http://wordpress.org/download/counter/">9.3 million downloads</a> of WordPress 3.8, we&#8217;re pleased to announce WordPress 3.8.1 is now available.</p>
<p>Version 3.8.1 is a maintenance releases that addresses 31 bugs in 3.8, including various fixes and improvements for the new dashboard design and new themes admin screen. An issue with taxonomy queries in WP_Query was resolved. And if you&#8217;ve been frustrated by submit buttons that won&#8217;t do anything when you click on them (or thought you were going crazy, like some of us), we&#8217;ve found and fixed this &#8220;dead zone&#8221; on submit buttons.</p>
<p>It also contains a fix for <strong>embedding tweets</strong> (by placing the URL to the tweet on its own line), which was broken due to a recent Twitter API change. (For more on Embeds, see <a href="http://codex.wordpress.org/Embeds">the Codex</a>.)</p>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.8.1">list of tickets</a> and <a href="https://core.trac.wordpress.org/log/branches/3.8?rev=27018&amp;stop_rev=26862">the changelog</a>. There&#8217;s also a <a href="http://make.wordpress.org/core/2014/01/22/wordpress-3-8-1-release-candidate/">detailed summary</a> for developers on the development blog.</p>
<p>If you are one of the millions already running WordPress 3.8, we will start rolling out automatic background updates for WordPress 3.8.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.8.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p>Thanks to all of these fine individuals for contributing to 3.8.1:</p>
<p><a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/collinsinternet">Allan Collins</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/cojennin">Connor Jennings</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/fboender">fboender</a>, <a href="http://profiles.wordpress.org/avryl">Janneke Van Dorpe</a>, <a href="http://profiles.wordpress.org/janrenn">janrenn</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="#">José Pino</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/matveb">Matias Ventura</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/nivijah">nivijah</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/undergroundnetwork">undergroundnetwork</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p><em>WordPress three eight one<br />
We heard you didn&#8217;t like bugs<br />
So we took them out</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2014/01/wordpress-3-8-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 02 Jun 2014 10:46:06 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 08 May 2014 18:40:58 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911030210";}', 'no') ; 
INSERT INTO `worldcup_options` VALUES (115, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1401749167', 'no') ; 
INSERT INTO `worldcup_options` VALUES (116, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1401705967', 'no') ; 
INSERT INTO `worldcup_options` VALUES (117, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1401749168', 'no') ; 
INSERT INTO `worldcup_options` VALUES (118, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Benjamin Caubère: Crear un plugin con el modelo Freemium en WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32798";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2014/06/02/benjamin-caubere-crear-un-plugin-con-el-modelo-freemium-en-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:723:"<div id="v-oVd0Ul78-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32798/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32798/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32798&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/benjamin-caubere-crear-un-plugin-con-el-modelo-freemium-en-wordpress/"><img alt="Benjamin Caubère: Crear un plugin con el modelo Freemium en WordPress" src="http://videos.videopress.com/oVd0Ul78/video-8036b88a1d_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 09:00:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:101:"WordPress.tv: Mercedes Romero: AlbertoContador.org – WordPress multisitio, multiidioma y red social";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32795";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://wordpress.tv/2014/06/02/mercedes-romero-albertocontador-org-wordpress-multisitio-multiidioma-y-red-social/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:752:"<div id="v-07Liu1Wd-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32795/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32795/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32795&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/mercedes-romero-albertocontador-org-wordpress-multisitio-multiidioma-y-red-social/"><img alt="Mercedes Romero: AlbertoContador.org – WordPress multisitio, multiidioma y red social" src="http://videos.videopress.com/07Liu1Wd/video-91f834ca2a_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 08:15:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: 10 New Free WordPress Themes From May 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23866";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:148:"http://wptavern.com/10-new-free-wordpress-themes-from-may-2014?utm_source=rss&utm_medium=rss&utm_campaign=10-new-free-wordpress-themes-from-may-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8191:"<p>May was an excellent month for free WordPress themes landing in the official Themes Directory. Several dozen were approved and added to the directory last week in one sweep. We&#8217;ve hand-picked some of the best themes released in the month of May, all of which have undergone the rigorous review process conducted by the Theme Review Team. Grab a coffee or tea and start bookmarking your favorites.</p>
<h3>Themify Base</h3>
<p><a href="http://wordpress.org/themes/themify-base"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/themify.png?resize=1025%2C769" alt="themify" class="aligncenter size-full wp-image-23868" /></a></p>
<p>Themify Base is a minimalist style blog theme from the folks at <a href="http://themify.me/" target="_blank">Themify</a>. It&#8217;s translation ready, includes one custom menu, a sidebar, and three footer widget areas. The theme options contain six different skins and multiple layouts for the index, archives, pages, and posts.</p>
<p><strong><a href="http://themify.me/demo/themes/base/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/themify-base" target="_blank">Download</a></strong></p>
<h3>Tracks</h3>
<p><a href="http://wordpress.org/themes/tracks"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg?resize=1000%2C600" alt="tracks" class="aligncenter size-full wp-image-23832" /></a></p>
<p>Tracks is a bold, beautiful theme designed for use on personal blogs. Making your site look just like the demo takes no time, as it features just a handful of options in the WordPress customizer. The theme looks its best with large, panoramic featured images in place for each post. It also includes a customized author section that will display social links and a bio for each author at the bottom of posts.</p>
<p><strong><a href="http://www.competethemes.com/tracks-live-demo" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/tracks" target="_blank">Download</a></strong></p>
<h3>Link</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/link.png" rel="prettyphoto[23866]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/link.png?resize=880%2C660" alt="link" class="aligncenter size-full wp-image-23874" /></a></p>
<p>Link based on Bootstrap and is an adaptation of the &#8220;Link&#8221; theme by Blacktie.co. It features big full-width images and full-width colored sections. The theme is actually a child theme of the <a href="http://wordpress.org/themes/flat-bootstrap" target="_blank">Flat Bootstrap</a> theme created by Tim Nicholson. Link includes support for customer header images, multiple widget areas, and Font Awesome icons.</p>
<p><strong><a href="http://wordpress.org/themes/link" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/link" target="_blank">Download</a></strong></p>
<h3>tdPersona</h3>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tdpersona.png" rel="prettyphoto[23866]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tdpersona.png?resize=880%2C660" alt="tdpersona" class="aligncenter size-full wp-image-23875" /></a></p>
<p>tdPersona is a beautiful theme with a clean, simple design. This minimal style theme has support for all of the standard post formats and includes a unique header menu for navigating them. A hidden sidebar widget area slides out when activated by an unobtrusive icon in the top menu.</p>
<p><strong><a href="http://demo.tdwp.us/tdpersona/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/tdpersona" target="_blank">Download</a></strong></p>
<h3>Forceful Lite</h3>
<p><a href="http://wordpress.org/themes/forceful-lite"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/forceful-lite.png?resize=600%2C450" alt="forceful-lite" class="aligncenter size-full wp-image-23876" /></a></p>
<p>Forceful Lite is a free theme suited to magazines, blogs and news sites. It includes multiple widget areas as well as the ability to create your own unique sidebars and assign them to individual posts/pages. The theme is packaged with 14 custom widgets for customizing the display of recent content, advertising, social links, and more.</p>
<p><strong><a href="http://kopatheme.com/demo/forceful-magazine-wordpress-theme-light-version/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/forceful-lite" target="_blank">Download</a></strong></p>
<h3>Carrot Lite</h3>
<p><a href="http://wordpress.org/themes/carrot-lite"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/carrot-lite.png?resize=880%2C660" alt="carrot-lite" class="aligncenter size-full wp-image-23877" /></a></p>
<p>The Carrot Lite homepage sports a magazine-style design with a large welcome message that can be easily edited in the customizer. The theme includes footer and sidebar widget areas and support for Font Awesome icons.</p>
<p><strong><a href="http://wordpress.org/themes/carrot-lite" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/carrot-lite" target="_blank">Download</a></strong></p>
<h3>Fictive</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/fictive.png" rel="prettyphoto[23866]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/fictive.png?resize=880%2C660" alt="fictive" class="aligncenter size-full wp-image-23878" /></a></p>
<p>Fictive is a beautiful free theme from Automattic, designed for bloggers. It can be customized with your own header, Gravatar and social links in the sidebar, which can be set to fixed or scroll. Fictive features post formats with different colors and icons for each.</p>
<p><strong><a href="http://fictivedemo.wordpress.com/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/fictive" target="_blank">Download</a></strong></p>
<h3>Make</h3>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/make.png" rel="prettyphoto[23866]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/make.png?resize=880%2C660" alt="make" class="aligncenter size-full wp-image-23250" /></a></p>
<p>Make is Theme Foundry&#8217;s first free WordPress theme. It includes a unique drag and drop page builder that makes it easy for anyone to customize the layout. The design can be further customized with your own background, fonts, colors, and logo. Make can be used as a base for nearly any kind of website, including portfolios, blogs, businesses, e-commerce, or magazine sites.</p>
<p><strong><a href="https://thethemefoundry.com/wordpress-themes/make/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/make" target="_blank">Download</a></strong></p>
<h3>Pictorico</h3>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png" rel="prettyphoto[23866]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/pictorico.png?resize=880%2C660" alt="pictorico" class="aligncenter size-full wp-image-22830" /></a></p>
<p>Pictorico is a single-column, grid-based portfolio theme created by the folks at Automattic. It&#8217;s well-suited to photoblogging or portfolio sites that feature large images. The theme can be customized with your own background and header. Pictorico also includes a post slider and support for post formats and sticky posts.</p>
<p><strong><a href="http://pictoricodemo.wordpress.com/" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/pictorico" target="_blank">Download</a></strong></p>
<h3>Quality</h3>
<p><a href="http://wordpress.org/themes/quality "><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/quality.png?resize=880%2C660" alt="quality" class="aligncenter size-full wp-image-23870" /></a></p>
<p>Quality is a business theme with a custom blog and homepage template. The options include the ability to upload your own logo and header image. Quality supports Font Awesome icons which are featured in the homepage services section and can be easily edited in the theme&#8217;s options.</p>
<p><strong><a href="http://wordpress.org/themes/quality" target="_blank">Demo</a> | <a href="http://wordpress.org/themes/quality" target="_blank">Download</a></strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 08:11:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:111:"WordPress.tv: Rafael Poveda: 30 cosas que no sabías que se podían hacer con un WordPress recién instalado";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=32500";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:122:"http://wordpress.tv/2014/06/02/rafael-poveda-30-cosas-que-no-sabias-que-se-podian-hacer-con-un-wordpress-recien-instalado/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:771:"<div id="v-Y3vXBBC9-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/32500/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/32500/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=32500&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/rafael-poveda-30-cosas-que-no-sabias-que-se-podian-hacer-con-un-wordpress-recien-instalado/"><img alt="Rafael Poveda: 30 cosas que no sabías que se podían hacer con un WordPress recién instalado" src="http://videos.videopress.com/Y3vXBBC9/video-f935c26916_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 07:00:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Syed Balkhi: KidsCamp Atlanta – Fundamental Decisions regarding your WordPress setup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35275";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://wordpress.tv/2014/06/02/syed-balkhi-kidscamp-atlanta-fundamental-decisions-regarding-your-wordpress-setup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:755:"<div id="v-Zw4VDHcJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35275/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35275/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35275&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/02/syed-balkhi-kidscamp-atlanta-fundamental-decisions-regarding-your-wordpress-setup/"><img alt="Syed Balkhi: KidsCamp Atlanta &#8211; Fundamental Decisions regarding your WordPress setup" src="http://videos.videopress.com/Zw4VDHcJ/video-9637bcec11_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 07:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Matt: Laundry-App Race";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43829";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:38:"http://ma.tt/2014/06/laundry-app-race/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:188:"<p>Jessica Pressler in New York Magazine has an unintentionally funny look at <a href="http://nymag.com/news/features/laundry-apps-2014-5/">Silicon Valley&#8217;s Laundry-App Race</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 20:22:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress.tv: Cliff Seal: Get Started in Professional WordPress Design and Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35255";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:103:"http://wordpress.tv/2014/06/01/cliff-seal-get-started-in-professional-wordpress-design-and-development/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:721:"<div id="v-Gb3K8ynt-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35255/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35255/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35255&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/cliff-seal-get-started-in-professional-wordpress-design-and-development/"><img alt="Cliff Seal: Get Started in Professional WordPress Design and Development" src="http://videos.videopress.com/Gb3K8ynt/video-d7ccd33426_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:37:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Bryan Petty: Finding the Perfect Themes and Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35243";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2014/06/01/bryan-petty-finding-the-perfect-themes-and-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:679:"<div id="v-233NQZiw-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35243/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35243/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35243&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/bryan-petty-finding-the-perfect-themes-and-plugins/"><img alt="Bryan Petty: Finding the Perfect Themes and Plugins" src="http://videos.videopress.com/233NQZiw/video-67347b08b9_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:34:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: David Laietta: Web Development Trends For 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35241";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2014/06/01/david-laietta-web-development-trends-for-2014/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:669:"<div id="v-F5Ynj9Ql-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35241/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35241/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35241&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/06/01/david-laietta-web-development-trends-for-2014/"><img alt="David Laietta: Web Development Trends For 2014" src="http://videos.videopress.com/F5Ynj9Ql/video-ccdb65be9b_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 18:31:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Akismet: May Stats Roundup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1505";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://blog.akismet.com/2014/06/01/may-stats-roundup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4480:"<p>Welcome to the second post in a series of monthly articles summarizing some stats and figures from the Akismet universe. You can find April&#8217;s post <a href="http://blog.akismet.com/2014/05/01/april-stats-roundup/">here</a>.</p>
<div id="attachment_1507" class="wp-caption alignright"><a href="http://akismet.files.wordpress.com/2014/06/8116030061_cd2098f723_o.jpg"><img class="wp-image-1507 size-medium" src="http://akismet.files.wordpress.com/2014/06/8116030061_cd2098f723_o.jpg?w=300&h=200" alt="Atos Olympic Games male swimmers diving two London 2012 by Atos on Flickr" width="300" height="200" /></a><p class="wp-caption-text">This image is a derivative of &#8216;<a href="https://www.flickr.com/photos/atosorigin/8116030061/">Atos Olympic Games male swimmers diving two London 2012</a>&#8216; by Atos. Used under <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC BY-SA</a></p></div>
<p>In May, Akismet caught a total of <strong>6,562,229,410</strong> pieces of spam &#8211; including comments, forum posts, contact form submissions, etc. To visualize this number, <strong>picture each piece of spam as a sugar cube</strong> &#8211; that&#8217;d be enough sugar cubes to fill about 6 and a fifth Olympic swimming pools.</p>
<p>The amount of spam we caught in May is up 4% from last month, and up 269% from May 2012. Here&#8217;s a breakdown of the spam and ham we detected each day:</p>
<p><a href="https://akismet.files.wordpress.com/2014/06/akismet-ham-stats-may-20141.png"><img src="http://akismet.files.wordpress.com/2014/06/akismet-ham-stats-may-20141.png?w=640&h=400" alt="Akismet Spam and Ham Stats, May 2014" width="640" height="400" class="alignnone size-large wp-image-1529" /></a></p>
<p>There weren&#8217;t any big dips or highs during the month of May. The busiest day of the month was May 8, with just over <strong>230 million</strong> spam messages detected. The slowest day was May 25, with &#8216;only&#8217; about 178 million pieces of spam caught. You may have seen similar ups and downs in the spam activity on your own site.</p>
<p>We had no service interruptions this month, so any fluctuations in spam numbers we attribute to the natural way spam is posted. If you want to hear about any service interruptions you can subscribe to this blog, or follow <a href="https://twitter.com/akismet">us on Twitter</a>.</p>
<p>As usual, there&#8217;s much more spam going around than real comments (which we call ham). You can see this by looking at the purple bars in the graph.</p>
<p>Akismet detected a total of 294,312,590 real messages in May. If each real comment were a sugar cube, they&#8217;d only enough be enough to fill about 10% of one Olympic swimming pool.</p>
<p>In May, we missed only about 1 in every 7,404 spam messages. If you&#8217;ve seeing lots of missed spam comments on your own site, we are happy to help with that, so feel free to <a href="http://akismet.com/contact/">contact us</a> about it, and please include your website &amp; your API key in your message.</p>
<p>
<strong>Some reads from the month that we recommend:</strong><br />
This month, we rather enjoyed reading <a href="http://www.theatlantic.com/technology/archive/2014/05/spam-always-finds-a-way/371194/">this piece</a> by Adrienne LaFrance about the history of spam (going back to snail mail!), and how it affects us nowadays. We also liked Seth Godin&#8217;s <a href="http://sethgodin.typepad.com/seths_blog/2014/04/what-is-spam.html">sage advice</a> (as always) on how not to spam people as a business, but still get business. In fact, in July <a href="http://blogs.windsorstar.com/2014/05/26/new-anti-spam-regulations-feature-tight-restrictions-hefty-fines/">Canada&#8217;s Anti-Spam legislation will come into effect</a> (<a href="http://www.techvibes.com/blog/a-guide-to-canadas-anti-spam-law-2014-05-20">similar to CAN-SPAM</a>), making the suggestions Seth Godin recommends, and even stricter rules around emailing, into law, which should make Canadians much happier with their inboxes <span class="wp-smiley emoji emoji-smile" title=":)">:)</span>. We like where this is going!</p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1505/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1505/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1505&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 06:00:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Valerie";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WordPress Plugin All In One SEO Releases Important Security Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23880";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/wordpress-plugin-all-in-one-seo-releases-important-security-update?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-plugin-all-in-one-seo-releases-important-security-update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2024:"<p>The popular <a title="http://wordpress.org/plugins/all-in-one-seo-pack/" href="http://wordpress.org/plugins/all-in-one-seo-pack/">All In One SEO Plugin</a> for WordPress has <a title="http://semperfiwebdesign.com/blog/all-in-one-seo-pack/all-in-one-seo-pack-release-history/" href="http://semperfiwebdesign.com/blog/all-in-one-seo-pack/all-in-one-seo-pack-release-history/">released an update</a> addressing two security issues <a title="http://blog.sucuri.net/2014/05/vulnerability-found-in-the-all-in-one-seo-pack-wordpress-plugin.html" href="http://blog.sucuri.net/2014/05/vulnerability-found-in-the-all-in-one-seo-pack-wordpress-plugin.html">discovered by Sucuri </a>during a security audit. According to Sucuri, one of the vulnerabilities can be used to escalate privileges while the other deals with Cross Site Scripting attacks.</p>
<div id="attachment_23882" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AllInOneSEOFeaturedImage.png" rel="prettyphoto[23880]"><img class="size-full wp-image-23882" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/AllInOneSEOFeaturedImage.png?resize=730%2C269" alt="All In One SEO Plugin Header Image" /></a><p class="wp-caption-text">All In One SEO Plugin Header Image</p></div>
<p>A logged-in user who doesn&#8217;t have administrative capabilities is able to modify certain parameters of the plugin such as the <strong>post&#8217;s SEO title, description, and meta tags</strong>. These changes could cause long-term negative effects to search engine rankings.</p>
<p>Unfortunately, this bug can also be used to execute malicious code on an administrator&#8217;s control panel. Sucuri says &#8220;this means that an attacker could potentially inject any JavaScript code and do things like change the admin’s account password to leaving some backdoor in your website’s files in order to conduct even more “evil” activities later.&#8221;</p>
<p>Sucuri recommends upgrading the plugin as soon as possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Jun 2014 02:34:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WordPress.tv: Ignacio de Miguel: La unión hace la fuerza: PHP, WordPress y creatividad";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25348";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2014/05/31/ignacio-de-miguel-la-union-hace-la-fuerza-php-wordpress-y-creatividad/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:720:"<div id="v-ahcdnnUU-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25348/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25348/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25348&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/ignacio-de-miguel-la-union-hace-la-fuerza-php-wordpress-y-creatividad/"><img alt="Ignacio de Miguel: La unión hace la fuerza: PHP, WordPress y creatividad" src="http://videos.videopress.com/ahcdnnUU/video-86eea2dfe6_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 09:00:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress.tv: Andy García: WordPress vs Drupal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25195";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2014/05/31/andy-garcia-wordpress-vs-drupal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:648:"<div id="v-tNhCssxb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25195/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25195/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25195&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/andy-garcia-wordpress-vs-drupal/"><img alt="Andy García: WordPress vs Drupal" src="http://videos.videopress.com/tNhCssxb/video-1efcaf2516_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 08:00:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WordPress.tv: Jorge Coronado: Hardening en WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25250";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.tv/2014/05/31/jorge-coronado-hardening-en-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:659:"<div id="v-79g7dalR-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25250/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25250/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25250&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/31/jorge-coronado-hardening-en-wordpress/"><img alt="Jorge Coronado: Hardening en WordPress" src="http://videos.videopress.com/79g7dalR/video-1b851666f8_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 07:00:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:90:"WPTavern: WPWeekly Episode 150 – Interview With Ryan Vaughn, CEO Of Varsity News Network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=23857&preview_id=23857";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:214:"http://wptavern.com/wpweekly-episode-150-interview-with-ryan-vaughn-ceo-of-varsity-news-network?utm_source=rss&utm_medium=rss&utm_campaign=wpweekly-episode-150-interview-with-ryan-vaughn-ceo-of-varsity-news-network";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2683:"<p>We started the show off with Andrew Nacin where he clarified a number of points dealing with the <a href="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/" title="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/">WordPress.com Cookie problem</a>. He also published a <a href="http://nacin.com/2014/05/30/security-is-nuanced/" title="http://nacin.com/2014/05/30/security-is-nuanced/">great post</a> explaining why security is nuanced.</p>
<p>The second part of the show featured an interview with <a href="http://varsitynewsnetwork.com/home" title="http://varsitynewsnetwork.com/home">Varsity News Network</a> CEO, Ryan Vaughn, to discuss how the company is utilizing WordPress to become the ESPN of high school sports. Using a custom designed theme, VNN provides more than 350 high schools across the country a website to publish informational events, schedules, and scores.</p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure" title="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure">WordPress.com Security Vulnerability Stirs Debate Over Responsible Disclosure</a><br />
<a href="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release" title="http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release">JSON REST API Slated For WordPress 4.1 Release</a><br />
<a href="http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page" title="http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page">Alex Shiels Proposal For Improving The WordPress Plugin Management Page</a><br />
<a href="http://wptavern.com/wordpress-celebrates-its-11th-birthday" title="http://wptavern.com/wordpress-celebrates-its-11th-birthday">WordPress Celebrates Its 11th Birthday</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, June 13th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #150:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 31 May 2014 03:01:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Tracks: A Free Bold WordPress Theme for Personal Blogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23829";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:170:"http://wptavern.com/tracks-a-free-bold-wordpress-theme-for-personal-blogs?utm_source=rss&utm_medium=rss&utm_campaign=tracks-a-free-bold-wordpress-theme-for-personal-blogs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3227:"<p><a href="http://wordpress.org/themes/tracks" target="_blank">Tracks</a> is a new free theme in the WordPress Themes Directory with a unique design that utilizes panoramic featured images. The homepage displays recent posts and a short excerpt for each, with big, bold images alternating down the page.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg" rel="prettyphoto[23829]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks.jpg?resize=1000%2C600" alt="tracks" class="aligncenter size-full wp-image-23832" /></a></p>
<p>If you&#8217;re looking for a simple theme with very few options to configure, then Tracks is a good pick. It has just a handful of customization options built into the WordPress customizer, which means it will take less than a minute to make your site look like the demo.</p>
<p>You can upload a logo image, set the navigation menu, add site title and tagline, and elect to use a static front page. Apart from those options, the design is set for you.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks-customizer.jpg" rel="prettyphoto[23829]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/tracks-customizer.jpg?resize=1025%2C587" alt="tracks-customizer" class="aligncenter size-full wp-image-23841" /></a></p>
<p>The only caveat with using this theme is that you&#8217;ll need to make sure you upload a large featured image for each post in order to keep the homepage looking colorful. The single posts page also uses that image for a panoramic display at the top of the content.</p>
<p>The author bio section allows each author on the site to display links to social profiles after each post. This is configured in the &#8220;Edit Profile&#8221; page in the admin.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/author-profile.jpg" rel="prettyphoto[23829]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/author-profile.jpg?resize=730%2C175" alt="author-profile" class="aligncenter size-full wp-image-23850" /></a></p>
<p>Tracks is 100% responsive. If you resize the <a href="http://www.competethemes.com/tracks-live-demo" target="_blank">live demo</a> page, you&#8217;ll see that the content responds nicely to various screen sizes. It was designed to work well on well on desktops, tablets and phones. It uses fitvids.js to make sure that videos in your posts are also responsive to devices.</p>
<p>The theme does not include any widget areas. As you can tell from the short list of options, Tracks is a design-specific theme focused on blog content and images. What you cannot see from the demo is that the theme is SEO-friendly with semantic link anchors and optimized title tags. It also incorporates ARIA-roles and follows basic accessibility guidelines.</p>
<p>Tracks was created by <a href="http://profiles.wordpress.org/BenSibley/" target="_blank">Ben Sibley</a> and is available for free from WordPress.org. <a href="http://www.competethemes.com/documentation/tracks-knowledgebase/" target="_blank">Documentation</a> can be found on the author&#8217;s website and includes instructions for customizing the theme with a child theme.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 23:13:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WPTavern: Feuilles App Aims to Replace Editorially, Offers Publishing to Github, WordPress, and Dropbox";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23791";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:244:"http://wptavern.com/feuilles-app-aims-to-replace-editorially-offers-publishing-to-github-wordpress-and-dropbox?utm_source=rss&utm_medium=rss&utm_campaign=feuilles-app-aims-to-replace-editorially-offers-publishing-to-github-wordpress-and-dropbox";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5076:"<p>Editorially closed its doors for good today, and with it goes all of the writing collaboration tools its users came to love. Unfortunately, some <a href="https://twitter.com/aworkinglibrary/status/465949423944884226" target="_blank">legal issues</a> are currently preventing them from open sourcing the code for the application, but it&#8217;s under consideration.</p>
<p>In the meantime, a newcomer has stepped in to provide some of the features that users loved best about Editorially. <a href="https://feuill.es/" target="_blank">Feuilles</a>, which means &#8220;paper sheets&#8221; in French, is a new app for helping people write together. It provides a markdown editor and a platform for discussing your texts with other people. If you have an Editorially export, you can import all of your documents into Feuilles and carry on writing.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/Feuilles.jpg" rel="prettyphoto[23791]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/Feuilles.jpg?resize=962%2C509" alt="Feuilles" class="aligncenter size-full wp-image-23799" /></a></p>
<p>Feuilles allows you to publish to Github, WordPress.com, and Dropbox, although the connections are still in the early/buggy stages, since the app is currently open to those interested in beta testing. It also works with Jetpack-enabled self-hosted WordPress sites.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/publish-Feuilles.jpg" rel="prettyphoto[23791]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/publish-Feuilles.jpg?resize=727%2C377" alt="publish-Feuilles" class="aligncenter size-full wp-image-23800" /></a></p>
<p><a href="https://twitter.com/alexduloz" target="_blank">Alex Duloz</a> and his partner <a href="https://twitter.com/_KatyWatkins" target="_blank">Katy Watkins</a> used Editorially extensively in their work with <a href="https://the-pastry-box-project.net/" target="_blank">The Pastry Box Project</a> while discussing texts and polishing their publishing skills. When Editorially announced that it was disappearing, they decided to create their own app but with a new twist: an emphasis on empowering people with a versatile API. Duloz explained the app&#8217;s purpose:</p>
<blockquote><p>Feuilles is not Editorially. It&#8217;s a new project that sits on the shoulders of giants. My fanboy-ism took the latter form, the one of a homage. If you were used to working in Editorially, the previous sentence will immediately make sense when you start using Feuilles. There is a certain “feeling” that characterized Editorially which has been preserved in Feuilles (the way conversations work, how the dashboard allows you to interact with documents), but you will find that using our website to write is in fact not the real purpose of our website.</p></blockquote>
<p>The power of Feuilles is in its <a href="https://feuill.es/documentation/api" target="_blank">API</a>; Duloz built the app for you to use with your own website. &#8220;Feuilles is here to provide publishers with <a href="https://feuill.es/documentation/api" target="_blank">a versatile API</a> (the same that we actually consume to operate) that they can use in their projects,&#8221; he said. <strong>&#8220;In fact, Feuilles is here so that you can launch collaborative blogs without even having to visit Feuilles. Our platform should just a be a means. Not an end.&#8221;</strong></p>
<p>The API allows you to work through HTTP requests, so there&#8217;s no need to use the Feuilles app in order to work. They&#8217;ve opened a few of their endpoints for developers to experiment with to use Feuilles from remote HTTP locations. The &#8220;<a href="https://feuill.es/documentation/in-house-publishing" target="_blank">In-House Publishing</a>&#8221; feature makes it possible for you to post data from Feuilles to your own website by <a href="https://feuill.es/console/applications" target="_blank">registering an application</a>. Requests received to your website are POST requests and right now there isn&#8217;t a WordPress plugin to automate the In-House Publishing feature, so you&#8217;d have to dive into the technical details if you want to try it out.</p>
<p>Duloz is aiming to make Feuilles a language/device agnostic CMS with In-House Publishing. As WordPress currently powers 22% of the web, it will be interesting to see how this app evolves to support people with self-hosted WordPress sites.</p>
<p>Those who participate in collaborative writing are a rather small segment of overall WordPress users. However, if the popularity of Editorially is any indication, Feuilles may have the chance to become the web&#8217;s go-to application for writing collaboratively. Since its creators intend for it to be a means, not an end, its likely to enjoy a different trajectory than Editorially. Coming out of the gate with a strong focus on its API is a shrewd move that will enable the <a href="https://feuill.es/" target="_blank">Feuilles</a> app to be used in a multitude of different ways.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 19:10:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Andrew Nacin: Security is nuanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:24:"http://nacin.com/?p=4235";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://nacin.com/2014/05/30/security-is-nuanced/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8171:"<p>As a software vendor, there are many reasons to prefer responsible disclosure of security issues. But the most important reason is also less obvious: vulnerability reports need to be <em>correct</em>.</p>
<p>I&#8217;ve seen countless &#8220;full disclosure&#8221; reports that are wrong and invalid. Most of these could have been prevented by privately disclosing it to the vendor and allowing them the opportunity to respond.</p>
<p>Everyone sees WordPress in the headlines, over and over again, but no one ever notices the &#8220;this report is invalid&#8221; response. We&#8217;ve prevented countless invalid reports from being published simply because they were disclosed to us first. This is better for the software&#8217;s users, who are otherwise left to scramble every time they see a report. They are not an expert, and often, neither is the reporter.</p>
<p>There&#8217;s another angle here, though: sometimes, the vulnerability report is correct, but <em>incomplete</em>. This too can send everyone scrambling, starting with the vendor who was not given the opportunity to straighten things out.</p>
<p>When responsible disclosure works, it works really well. I offer <a href="http://jetpack.me/2014/04/10/jetpack-security-update/">Jetpack&#8217;s recent vulnerability</a> as a recent case study. While this was discovered internally at Automattic, the effect is the same: they were able to quickly and thoroughly investigate the issues and follow through with a plan of action. During their investigation they learned the problem was far more severe than they originally identified, and that their initial proposed fix was incomplete.</p>
<p>There will always be individuals who want everything to be fully disclosed, and there are some great arguments for that. I&#8217;m not trying to sway you one way or the other. But if you&#8217;re trying to do the right thing — you&#8217;re doing full disclosure in the interest of users, possibly even providing a patch or steps to mitigate — working with the vendor is a good way to ensure you haven&#8217;t missed anything.</p>
<p>I&#8217;m not sure how many times now I&#8217;ve responded to a mailing list saying, &#8220;well, this isn&#8217;t a vulnerability,&#8221; or &#8220;your proposed patch is incomplete,&#8221; or &#8220;your patch makes it worse.&#8221; Or when I don&#8217;t respond to the mailing list because my thought is <em>T</em><em>his is worse than the reporter realizes.</em></p>
<p>Security is nuanced.</p>
<p>Last week, a security researcher disclosed some issues with WordPress. They stated that WordPress issues a cookie in plain HTTP that identifies the user. Correct. They also stated that this cookie does not expire when the user logs out. Also correct.</p>
<p>She went on to state that the cookie has a lifetime of 3 years, that it can be used to mess with the account&#8217;s two-factor authentication settings, and change their email and other settings. She followed that up with &#8220;have notified them and waited 24hrs for response, none yet. guessing it&#8217;s a wontfix for now, since their SSL support is patchy.&#8221;</p>
<p>Yes, absolutely, SSL support in WordPress is patchy. (Coincidentally, fixing all of this was already slated for the next major release.) While you can force SSL for the dashboard, we don&#8217;t have the concept of forcing SSL for the front-end of the site. So, that &#8220;logged in&#8221; cookie is issued over plain HTTP. It&#8217;s trivial in a plugin to force that cookie to be secure, but of course most users aren&#8217;t going to do that. Of course, most users also aren&#8217;t using SSL (sadly).</p>
<p>WordPress also doesn&#8217;t have any concept of session management. The user is authenticated and a cookie is issued, but there&#8217;s no way for it to be automatically invalidated upon logout (without you changing your password). Changing this is a major architectural change we&#8217;ve been planning for some time. But this is also why cookies are designed with a limited expiration: just 48 hours, or 14 days if you click &#8220;Remember me.&#8221;</p>
<p>But the report was that it didn&#8217;t expire for three years, right? This is where it gets a bit weird. I&#8217;d love it if &#8220;Remember me&#8221; remembered you for 30, 90, or even 365 days, but WordPress will wait to make any changes until cookies can be invalidated. Some time ago, though, WordPress.com configured this cookie to last for three years.</p>
<p>Normally, this wouldn&#8217;t be that bad. You see, the &#8220;logged in&#8221; cookie is <em>relatively</em> harmless. It allows presentational things like the toolbar, edit links in your theme, and such. But you can&#8217;t use it to manage your account, change your email, or do anything particularly crazy. In fact, WordPress issues a separate, secure &#8220;auth&#8221; cookie used for the &#8220;wp-admin&#8221; dashboard. It’s like Amazon knowing who you are after six months of not being on the site, but asking you to log in when you start to check out.</p>
<p>On WordPress.com, however, a lot of settings can be managed outside of the dashboard, on their &#8220;new dashboard,&#8221; at wordpress.com/settings/. As you might have guessed by now, they were not requiring the &#8220;auth&#8221; cookie on this page, only the &#8220;logged in&#8221; cookie. That is the true critical vulnerability here. A number of decisions came together to make a latent issue a very real one. The issue wasn&#8217;t reported like this because the reporter isn&#8217;t familiar with the intricacies of user authentication internals in WordPress, nor should anyone expect them to. Rather, an assumption was made it was a design decision that would probably just be a &#8220;wontfix&#8221; due to &#8220;patchy&#8221; SSL support.</p>
<p>The disclosure was well-intentioned, but because it happened within just 24 hours, Automattic wasn&#8217;t able to react quickly enough to identify the actual issue and request that it not be disclosed until they got a fix in place.</p>
<p>I&#8217;m just trying to set the record straight on what happened, since I keep seeing confused tweets, blog posts, comments, and Facebook chatter. (Favorite Facebook comment, after I posted a brief explanation: &#8220;Did we just open all those nesting doll layers to discover the belly was empty?&#8221;) This situation probably could have been handled better by everyone involved, but that&#8217;s not really the point. The primary issue is now handled, and other issues are also being addressed. I don&#8217;t think this requires post-mortem blog posts with a side of FUD. I&#8217;m not looking for a debate on full disclosure versus responsible disclosure. And I certainly don&#8217;t think anyone should be questioning the researcher, who has spent years dedicating herself to making the Internet more secure.</p>
<p>In this case, WordPress.com the service was able to react quickly to mitigate this issue for all of its users. Of course, with software, holes can&#8217;t be closed so easily, and in this case, the situation was probably exacerbated by confusing WordPress.com the service with WordPress the software. That confusion is easy to understand, especially since some of these issues have roots in the core software.</p>
<address>Security is nuanced.</address>
<p><em>I&#8217;ve not linked to any previous posts because I don&#8217;t want this to be a criticism of any researcher or writer, but if you&#8217;re looking for background: <a href="https://zyan.scripts.mit.edu/blog/wordpress-fail/">1</a> <a href="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/">2</a> <a href="http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure">3</a>. Also, related work for WordPress 4.0 is happening <a href="https://core.trac.wordpress.org/query?milestone=4.0&component=Security">here</a>.</em></p>
<p class="share-sfc-stc"><a href="http://twitter.com/share?url=http%3A%2F%2Fwp.me%2FpQEdq-16j&count=horizontal&related=nacin&text=Security is nuanced" class="twitter-share-button"></a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 18:44:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WPTavern: WordPress Think Tank 2 Now Available To Watch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23796";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:154:"http://wptavern.com/wordpress-think-tank-2-now-available-to-watch?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-think-tank-2-now-available-to-watch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1430:"<p>The second ever <a title="http://wpthinktank.com/" href="http://wpthinktank.com/">WP Think Tank </a>hosted by Troy Dean is now available to watch. WP Think Tank is a by-product of the <a title="http://www.wpelevation.com/category/podcast/" href="http://www.wpelevation.com/category/podcast/">WP Elevation podcast</a>. The two hour-long show is filled with great information from some of the brightest minds working with large WordPress clients every day.</p>
<ul>
<li>Matt Medeiros &#8211; Founder of the MattReport</li>
<li>Alex King &#8211; CTO of Crowd Favorite</li>
<li>Lisa Sabin-Wilson &#8211; Partner at WebDevStudios and AppPresser</li>
<li>Brian Clark &#8211; CEO of Copyblogger</li>
<li>Tim Willmot &#8211; CEO of Human Made, Happy Tables, WP Remote</li>
<li>Miriam Schwab &#8211; Co-CEO and Founder of Illuminea</li>
<li>Cory Miller &#8211; CEO of iThemes.</li>
</ul>
<p>The first hour of the show centered around the topic of enterprise and whether WordPress is a suitable solution for both enterprise clients and eCommerce websites. The second hour of the show covered things from a user point of view. For instance, does WordPress deliver on the expectations of the average user or has it become too difficult to use? Are there too many options and navigation headaches in the backend causing user frustration?</p>
<p>Give it a listen and let us know what you think.</p>
<p><span class="embed-youtube"></span></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 18:24:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WordPress.tv: Matteo Cavucci: Io odio i temi di WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17315";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.tv/2014/05/30/matteo-cavucci-io-odio-i-temi-di-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:641:"<div id="v-Ivmk1LCc-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17315/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17315/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17315&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/matteo-cavucci-io-odio-i-temi-di-wordpress/"><img alt="01 Matteo Cavucci.mp4" src="http://videos.videopress.com/Ivmk1LCc/video-f40fad27f1_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 09:00:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:113:"WordPress.tv: Andrea Cardinali: 5 Regole SEO per sviluppo temi e plugin + 50 tips su Web Performance Optimization";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17367";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wordpress.tv/2014/05/30/andrea-cardinali-5-regole-seo-per-sviluppo-temi-e-plugin-50-tips-su-web-performance-optimization/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:773:"<div id="v-KB03gyQb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17367/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17367/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17367&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/andrea-cardinali-5-regole-seo-per-sviluppo-temi-e-plugin-50-tips-su-web-performance-optimization/"><img alt="Andrea Cardinali: 5 Regole SEO per sviluppo temi e plugin + 50 tips su Web Performance Optimization" src="http://videos.videopress.com/KB03gyQb/video-fa5ff5b75c_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 08:00:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WordPress.tv: Mattia Compagnucci: L’uso efficace di una Tipografia corretta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17357";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wordpress.tv/2014/05/30/mattia-compagnucci-luso-efficace-di-una-tipografia-corretta/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-FnT6vRQs-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17357/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17357/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17357&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/30/mattia-compagnucci-luso-efficace-di-una-tipografia-corretta/"><img alt="Mattia Compagnucci: L’uso efficace di una Tipografia corretta" src="http://videos.videopress.com/FnT6vRQs/video-d6e3e5a252_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 07:00:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WordPress Query Recorder Plugin: Record and Save Queries to a SQL File for Deployment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23767";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:232:"http://wptavern.com/wordpress-query-recorder-plugin-record-and-save-queries-to-a-sql-file-for-deployment?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-query-recorder-plugin-record-and-save-queries-to-a-sql-file-for-deployment";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2934:"<p><a href="https://wordpress.org/plugins/query-recorder/" target="_blank">Query Recorder</a> is a new tool that allows developers to record queries while working in the WordPress admin. The plugin was created by Brad Touesnard, author of the popular <a href="http://wptavern.com/wordpress-plugin-review-wp-db-migrate" target="_blank">WP Migrate DB</a> plugin. Touesnard introduced Query Recorder earlier this month at WordCamp Miami during his presentation on database deployment strategy.</p>
<p>Once installed, the plugin allows you to create recordings that save queries run by your theme or plugins. The recordings are sent to a sql file located in your /uploads/ directory.</p>
<p>The settings page gives you the option to set exclusions for certain types of queries and elect to omit or record queries that begin with insert, update, delete, drop, and create.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder-settings.png" rel="prettyphoto[23767]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder-settings.png?resize=1025%2C904" alt="query-recorder-settings" class="aligncenter size-full wp-image-23773" /></a></p>
<p>Clicking the button in the admin bar will start or stop the recording:</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/start-stop-recording.png" rel="prettyphoto[23767]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/start-stop-recording.png?resize=1025%2C736" alt="start-stop-recording" class="aligncenter size-full wp-image-23774" /></a></p>
<p>Once you&#8217;ve made a recording, open up the SQL file in your uploads folder and you&#8217;ll find your saved queries. In the example below you can see that I&#8217;ve enabled and disabled some plugins and themes.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder.png" rel="prettyphoto[23767]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/query-recorder.png?resize=1025%2C447" alt="query-recorder" class="aligncenter size-full wp-image-23771" /></a></p>
<p>Query Recorder can be particularly useful when working on a local installation of WordPress. You can record queries as you&#8217;re setting up a theme or plugin and create a SQL script that can be run later when deploying to another site. You can quickly test plugins and themes and then import the sql file when setting them up on a staging or live site. This is much easier than having to repeat those exact steps again in another environment.</p>
<p>I tested the plugin and it works exactly as advertised. Download <a href="https://wordpress.org/plugins/query-recorder/" target="_blank">Query Recorder</a> for free from the WordPress plugin directory. If you&#8217;d like to contribute to the project, it&#8217;s also hosted on <a href="https://github.com/deliciousbrains/wp-query-recorder" target="_blank">Github</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 May 2014 03:42:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WPTavern: Alex Shiels Proposal For Improving The WordPress Plugin Management Page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23671";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:206:"http://wptavern.com/alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page?utm_source=rss&utm_medium=rss&utm_campaign=alex-shiels-proposal-for-improving-the-wordpress-plugin-management-page";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5312:"<p>While WordPress <a title="http://wptavern.com/wordpress-3-8-parker-released" href="http://wptavern.com/wordpress-3-8-parker-released">3.8</a> and <a title="http://wptavern.com/wordpress-3-9-smith-released" href="http://wptavern.com/wordpress-3-9-smith-released">3.9</a> substantially improved the theme experience within WordPress, the plugins page hasn&#8217;t had the same treatment. In fact, the page hasn&#8217;t changed much since 2.7.</p>
<div id="attachment_23752" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordPress27PluginsPage.png" rel="prettyphoto[23671]"><img class="size-full wp-image-23752" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/WordPress27PluginsPage.png?resize=831%2C537" alt="WordPress 2.7 Plugins Page" /></a><p class="wp-caption-text">WordPress 2.7 Plugins Page</p></div>
<p>However, that may change as Alex Shiels has proposed a <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/">detailed outline</a> explaining the improvements and changes he&#8217;d like to see. According to Shiels, the goal is to improve the experience for both new and experienced users.</p>
<p>One of the suggested improvements is to have the plugin-install.php be the default page when selecting the Plugins menu in the backend of WordPress. I generally use the plugins page to activate or deactivate plugins for troubleshooting purposes. By making plugin-install.php the default page, it would require an extra step to browse to the installed plugins page.</p>
<p>Instead, I&#8217;d rather the default page be left alone and enable the search box to find plugins within the directory. Other users <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15346" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15346">have chimed in</a> with similar feedback. As Shiels mentioned, &#8220;the Search Installed Plugins box on plugins.php is easily mistaken for a plugin directory search.&#8221;</p>
<div id="attachment_23753" class="wp-caption aligncenter"><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PluginSearchBox.png" rel="prettyphoto[23671]"><img class="size-full wp-image-23753" src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/PluginSearchBox.png?resize=807%2C455" alt="Users Mistakenly Use The Search Box To Search The Plugin Directory" /></a><p class="wp-caption-text">Users Mistakenly Use The Search Box To Search The Plugin Directory</p></div>
<p>I want the search engine for plugins to be improved. I&#8217;d also like to be able to organize search results by ratings, reviews, download count, etc. I&#8217;m happy to see the tag cloud may potentially be removed in favor of specific categories.</p>
<p>Something I&#8217;d love to see is the ability to rate and review plugins from the backend of WordPress. This way, I wouldn&#8217;t have to visit each plugin&#8217;s page on the directory to give feedback. I&#8217;d also like to be able to access that information somehow on the Installed Plugins page.</p>
<p>I think the Visit Plugin Site URL should link to the WordPress.org page listing for the plugin, not the author&#8217;s website. It would make it a lot easier to find the appropriate location to get support or view other data about the plugin on WordPress.org.</p>
<h3>User Submitted Ideas</h3>
<p>There are a lot of great ideas in the comments of the post. For instance, <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15350" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/#comment-15350">Brad Tousnard suggested</a> a Plugin installation that uses AJAX to install plugins in-place instead of having to go through a series of steps or have separate browser tabs open to install multiple plugins.</p>
<p>The plugin page doesn&#8217;t show whether or a not a plugin is dependent on another to work properly. Although there is a <a title="https://core.trac.wordpress.org/ticket/11308" href="https://core.trac.wordpress.org/ticket/11308">four-year old trac ticket</a> that has a lengthy discussion about the topic, nothing concrete has been established. Once it&#8217;s out, the next step would be to create an easy way to see those dependencies when searching for plugins.</p>
<h3>How to Get Involved</h3>
<p>Since nearly everyone has experience managing plugins in WordPress, it&#8217;s no wonder the post is generating so much feedback. If you want to get involved with helping Shiels make improvements to the page, keep an eye on the <a title="https://core.trac.wordpress.org/component/Plugins" href="https://core.trac.wordpress.org/component/Plugins">Plugins Component</a> on Trac. This is where tickets specifically for that part of WordPress will be located. You can also <a title="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/" href="http://make.wordpress.org/core/2014/05/28/improving-the-plugins-page/">leave feedback on the post</a> with suggestions you have.</p>
<p>What changes would you like to see that would improve searching, adding, and managing plugins in WordPress for new and advanced users?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 21:32:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:91:"WPTavern: WP-CFM: A Free Plugin for Storing and Deploying WordPress Database Configurations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23708";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:224:"http://wptavern.com/wp-cfm-a-free-plugin-for-storing-and-deploying-wordpress-database-configurations?utm_source=rss&utm_medium=rss&utm_campaign=wp-cfm-a-free-plugin-for-storing-and-deploying-wordpress-database-configurations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4903:"<p><a href="http://forumone.github.io/wp-cfm/" target="_blank">WP-CFM</a> is a new free tool for WordPress created by <a href="https://twitter.com/mgibbs189" target="_blank">Matt Gibbs</a>, author of the popular <a href="http://wordpress.org/plugins/custom-field-suite/" target="_blank">Custom Field Suite</a> plugin. It provides configuration management for WordPress database changes, similar to Drupal&#8217;s <a href="https://drupal.org/project/features" target="_blank">Features</a> module.</p>
<p>WP-CFM lets you create and store bundles, which are essentially a group of one or more configuration options. The first step after installing the plugin is to create a /wp-content/config/ directory and grant write access.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-bundle.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/add-bundle.jpg?resize=967%2C339" alt="add-bundle" class="aligncenter size-full wp-image-23730" /></a></p>
<p>WP-CFM provides a friendly interface for viewing the contents of the wp_options table so that you can select the options you want to be stored in a specific bundle. For example, let&#8217;s say that you want to grab all of your Jetpack options for deploying somewhere else. Create a Jetpack bundle:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/jetpack-bundle.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/jetpack-bundle.jpg?resize=892%2C530" alt="jetpack-bundle" class="aligncenter size-full wp-image-23733" /></a></p>
<p>Each bundle has options for diff, push and pull:</p>
<ul>
<li><strong>diff</strong> &#8211; comparison of database version vs the file version</li>
<li><strong>push</strong> &#8211; write database changes to the file system</li>
<li><strong>pull</strong> &#8211; import file changes in the database</li>
</ul>
<p>Selecting &#8216;push&#8217; will store the database configuration in the file system (wp-content/config) as a .json file that you can then pull into your database at a later time or pull into another server.</p>
<p>One very common example where WP-CFM would be helpful is in the case of widgets options. Step one is to create a widgets bundle:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widget-options.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widget-options.jpg?resize=818%2C380" alt="widget-options" class="aligncenter size-full wp-image-23737" /></a></p>
<p>Next you would create a widgets diff:</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widgets-diff.jpg" rel="prettyphoto[23708]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/widgets-diff.jpg?resize=966%2C390" alt="widgets-diff" class="aligncenter size-full wp-image-23738" /></a></p>
<p>From here you can push those changes to the filesystem so they&#8217;re ready to deploy at another time. Most of the time when using WP-CFM, you&#8217;ll follow this basic workflow for storing and deploying configurations:</p>
<ol>
<li>Make database changes</li>
<li>Store them in configuration management</li>
<li>Push the file to another server</li>
</ol>
<p>The &#8216;push&#8217; option on the All Bundles item writes all of your bundles to the file system at once, which is fairly handy. WP-CFM also includes developer hooks for registering custom configuration items, including a callback parameter for configuration data that is not stored within wp_options.</p>
<p>Deploying bundles is really easy with WP-CFM&#8217;s support for WP-CLI, which enables you to pull or push bundles from the command line. Setting the bundle_name to &#8220;all&#8221; will push/pull all at once:</p>
<pre class="brush: php; light: true; title: ; notranslate">wp config pull &lt;bundle_name&gt;
wp config push &lt;bundle_name&gt;</pre>
<h3>Benefits of using WP-CFM</h3>
<p>WP-CFM can save you quite a bit of time when working alone but it really shines when working with team of multiple developers. In the docs, Gibbs identifies the benefits of including it in your workflow:</p>
<ul>
<li>Less need to copy the database. If you make changes, Push your bundle to the filesystem. To load changes, Pull the bundle into your database.</li>
<li>No need to manually apply database settings changes. No more &#8220;fire drills&#8221; where you&#8217;re rushing to figure out which settings you forgot to change.</li>
<li>Track and migrate configuration files using git, subversion, etc.</li>
</ul>
<p>WP-CFM is an excellent new tool for simplifying deployments and the best part is that it&#8217;s totally free. You can download it from <a href="https://github.com/forumone/wp-cfm" target="_blank">Github</a> or via the plugin&#8217;s <a href="http://forumone.github.io/wp-cfm/" target="_blank">homepage</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 19:05:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WPTavern: TeslaThemes Celebrates One Year Of Being In Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23669";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:168:"http://wptavern.com/teslathemes-celebrates-one-year-of-being-in-business?utm_source=rss&utm_medium=rss&utm_campaign=teslathemes-celebrates-one-year-of-being-in-business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3971:"<p>When I <a title="http://wptavern.com/interview-with-brand-new-theme-club-teslathemes" href="http://wptavern.com/interview-with-brand-new-theme-club-teslathemes">discovered TeslaThemes last year</a>, their unique looking designs really impressed me. Since so many other theme shops have tried the theme club model and failed, I didn&#8217;t have much hope for them. However, the company is celebrating <a title="http://teslathemes.com/blog/celebrating-our-1st-year-anniversary-with-fantastic-offers/" href="http://teslathemes.com/blog/celebrating-our-1st-year-anniversary-with-fantastic-offers/">their first year</a> of being in business.</p>
<p><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/TeslaThemesFeaturedImage.png" rel="prettyphoto[23669]"><img class="aligncenter size-full wp-image-23716" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/TeslaThemesFeaturedImage.png?resize=650%2C200" alt="TeslaThemes Birthday Featured Image" /></a>The theme club model typically fails because it over promises and under delivers. The model is especially difficult for small 1-3 person businesses. While time is devoted to churning out new products, there also needs to be support in place for previously released items.</p>
<p>TeslaThemes co-founder, Marcel Sobieski, told me they have released two new themes per month since launching the business while maintaining a customer satisfaction rating of 98% based on their monthly surveys. Sobieski says one of the greatest challenges the company faced is their rapid growth. &#8220;The greatest challenge TeslaThemes overcame in the first year is the fact that we are one of the fastest growing and healthy Premium WP Theme Clubs with a very strong community and stable workflow.&#8221;</p>
<p>The company is part of the <a title="http://www.red-sky.com/" href="http://www.red-sky.com/">Red Sky group</a>, a Polish investment firm. &#8220;The financial perspective wasn&#8217;t the most important concern. This gave us the opportunity to focus purely on quality and roll out. At the moment, we are financially independent and have great plans ahead&#8221; Sobieski said. This is a luxury not many theme shops get to take advantage of.</p>
<p>When asked what pivotal lessons were learned during the first year of business, Sobieski replied:</p>
<blockquote><p>Quality. This is the essence of this business. There are thousands of WP themes on the market, many of them are free, many are ripped, many are stolen, but what a simple user or advanced design studio needs is actual quality. Before going live, every developer or designer must be sure they provide what the market needs plus something special, and not just duplicate existing and successful WP themes.</p></blockquote>
<p>With some WordPress commercial theme business owners discussing whether <a title="http://chriswallace.net/wordpress-themes-become-commodity/" href="http://chriswallace.net/wordpress-themes-become-commodity/">WordPress themes have become a commodity,</a> there is also the advice of concentrating on a specific niche. TeslaThemes plans on creating more themes to expand their catalog to cover more niches. If Chris Lema is right about <a title="http://chrislema.com/more-future-of-wordpress-themes/" href="http://chrislema.com/more-future-of-wordpress-themes/">theme purchasing patterns</a>, it will end up being a good strategy.</p>
<p>For year number two, Sobieski says they&#8217;ll focus on co-operation with their customers while creating a 24/7 dedicated support channel. They&#8217;re also working on a new project called TeslaLab. TeslaLab is a dedicated paid customization center where customers can receive professional help with customizing their theme.</p>
<p>So far, the company has proven that the club model can work but is it a sustainable model for long-term success? Only time will tell.</p>
<p>Have you done business with TeslaThemes? If so, please share your experience in the comments.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 18:22:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Mirko Santangelo: Alla scoperta del Responsive Web Design per WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17335";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://wordpress.tv/2014/05/29/mirko-santangelo-alla-scoperta-del-responsive-web-design-per-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:719:"<div id="v-SdO82YD8-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17335/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17335/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17335&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/29/mirko-santangelo-alla-scoperta-del-responsive-web-design-per-wordpress/"><img alt="Mirko Santangelo: Alla scoperta del Responsive Web Design per WordPress" src="http://videos.videopress.com/SdO82YD8/video-0a28557891_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 09:00:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:109:"WordPress.tv: Matej Lančarič, Ondrej Monsberger: Ako nám pomohol woocommerce zdvojnásobiť návštevnosť";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35163";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:117:"http://wordpress.tv/2014/05/29/matej-lancaric-ondrej-monsberger-ako-nam-pomohol-woocommerce-zdvojnasobit-navstevnost/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:758:"<div id="v-n2LnFRz5-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35163/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35163/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35163&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/29/matej-lancaric-ondrej-monsberger-ako-nam-pomohol-woocommerce-zdvojnasobit-navstevnost/"><img alt="Matej Lančarič, Ondrej Monsberger: Ako nám pomohol woocommerce zdvojnásobiť návštevnosť" src="http://videos.videopress.com/n2LnFRz5/video-7c58dcb58c_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 08:00:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:96:"WordPress.tv: Michal Bluma: Comment changer la couleur d’un bouton sans anéantir l’univers?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33397";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wordpress.tv/2014/05/29/michal-bluma-comment-changer-la-couleur-dun-bouton-sans-aneantir-lunivers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:739:"<div id="v-NzIqHIuz-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33397/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33397/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33397&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/29/michal-bluma-comment-changer-la-couleur-dun-bouton-sans-aneantir-lunivers/"><img alt="Michal Bluma: Comment changer la couleur d’un bouton sans anéantir l’univers?" src="http://videos.videopress.com/NzIqHIuz/video-37dff4466e_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2014 07:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: This Week On WPWeekly: The CEO Of Varsity News Network, Ryan Vaughn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23674";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:194:"http://wptavern.com/this-week-on-wpweekly-the-ceo-of-varsity-news-network-ryan-vaughn?utm_source=rss&utm_medium=rss&utm_campaign=this-week-on-wpweekly-the-ceo-of-varsity-news-network-ryan-vaughn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1324:"<p>This Friday at 3P.M. Eastern on <a href="http://wptavern.com/wordpress-weekly" title="http://wptavern.com/wordpress-weekly">WordPress Weekly</a>, we&#8217;ll be joined by Ryan Vaughn, CEO of <a title="http://varsitynewsnetwork.com/home" href="http://varsitynewsnetwork.com/home">Varsity News Network</a>, to discuss how the company is utilizing WordPress to become the ESPN of high school sports. Using a custom designed theme, VNN provides more than 350 high schools across the country a website to publish informational events, schedules, and scores.</p>
<p>VNN increases exposure and recognition for high school athletes, and empowers students interested in media to gain experience in the field.</p>
<p></p>
<p>The company <a href="http://www.xconomy.com/detroit/2014/02/18/varsity-news-network-lands-3000000-new-funding/" title="http://www.xconomy.com/detroit/2014/02/18/varsity-news-network-lands-3000000-new-funding/">recently received $3M</a> in venture capital funding to help scale the service nationwide. Take a look at the list of <a href="http://varsitynewsnetwork.com/vnn-partner-schools/" title="http://varsitynewsnetwork.com/vnn-partner-schools/">partner schools</a> to see example websites using the VNN platform.</p>
<p>If you have any questions about the service, submit them in the comments below.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 23:45:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: JSON REST API Slated For WordPress 4.1 Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23676";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:156:"http://wptavern.com/json-rest-api-slated-for-wordpress-4-1-release?utm_source=rss&utm_medium=rss&utm_campaign=json-rest-api-slated-for-wordpress-4-1-release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6843:"<p>WordPress core contributors came to a consensus today during the development meeting regarding the immediate future of the JSON REST API project. Ryan McCue and his team released <a href="http://wptavern.com/wordpress-json-rest-api-version-1-0-released" target="_blank">version 1.0</a> over the weekend and have been pushing hard for it to be ready for the upcoming 4.0 release.</p>
<p>When I spoke with McCue yesterday about the API&#8217;s readiness for 4.0, he said, &#8220;At this point, the API is considered feature complete. The upcoming 1.1 release is going to be heavily focused on testing and documentation, plus some general bug fixing as per usual. Moving forward, we&#8217;ll basically just be building out new features as needed.&#8221;</p>
<p>The discussion today resulted in an agreement to put the WP API project on the 4.1 roadmap, as it still hasn&#8217;t received the requisite testing and real-world exposure that core contributors would like to see before giving it the green light.</p>
<p>&#8220;I think it&#8217;s &#8216;ready&#8217; for use, which is exciting,&#8221; Nacin said, when weighing in on the API during the meeting. <strong>&#8220;Now we just have to get it ready for the next five years and 22% of the internet.&#8221;</strong></p>
<p>Nacin suggested putting it squarely on the 4.1 roadmap with hopes of attracting more core contributors for the final mile. Although everyone is excited about having this new API in core, it&#8217;s an addition that all agreed is worthy of stronger core feedback before pushing it forward.</p>
<h3>The WP API in the Wild</h3>
<p>Meanwhile, more real-world examples of the API in use are popping up. <a href="https://twitter.com/ericandrewlewis" target="_blank">Eric Andrew Lewis</a>, a web developer for the New York Times, remarked, &#8220;We&#8217;re implementing it as of yesterday because it&#8217;s stable now.&#8221; <a href="https://twitter.com/kadamwhite" target="_blank">K. Adam White</a> also <a href="http://make.wordpress.org/core/2014/05/25/json-rest-api-version-1-0/#comment-15415" target="_blank">commented</a> on the most recent make.wordpress.org update to report that his team is already making use of the API at <a href="http://bocoup.com/" target="_blank">Bocoup</a>.</p>
<blockquote><p>We’re using the API as the content backend for an in-development Node.js website and several single-page applications; nothing I can share publicly yet, but the API project was the tipping point that let me convince my colleagues that WordPress was a suitable backend for a non-PHP application. We’re really excited about the work we’re doing and I look forward to sharing it later in the year.</p></blockquote>
<p>Although McCue feels that the API is ready for WordPress 4.0, those present at the development meeting agreed that more eyes and testers will help to ensure that the API enters core in a more robust state.</p>
<h3>How WordPress Plugin and Theme Developers Can Help Test the WP API</h3>
<div id="attachment_23698" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/building.jpg" rel="prettyphoto[23676]"><img src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/building.jpg?resize=1024%2C526" alt="photo credit: shenamt - cc" class="size-full wp-image-23698" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/shenamt/6906784503/">shenamt</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>WordPress developers are already doing some exciting things, such as creating plugins based on the API, i.e. the <a href="https://github.com/modemlooper/buddypress-json-api" target="_blank">BuddyPress JSON API</a> and the <a href="https://github.com/pods-framework/pods-json-api" target="_blank">Pods JSON API</a> that emerged shortly after 1.0 was released. McCue believes that finding your own special interest is a good way to join in testing the API:</p>
<blockquote><p>Contributing to a large project like WordPress core or the API isn&#8217;t always the easiest thing to do; these projects have certain rules and standards that can be annoying to have to deal with. The API is very much structured as the base for developers to build off, and it&#8217;s always much easier building with something you know, so I think finding something you&#8217;re familiar with and trying to integrate that with the API is a great way to both learn it, and help us test it out.</p></blockquote>
<p>McCue is also keen to get WordPress theme developers testing the API with their projects, using the project&#8217;s <a href="https://github.com/WP-API/client-js" target="_blank">Javascript library</a>. <strong>&#8220;We&#8217;ve tried to design this so that even frontend developers with minimal knowledge of WordPress can go out and start creating, and those with WP knowledge can feel at home,&#8221;</strong> he said.</p>
<p>During the development meeting McCue was asked about the advantages of theming with the API vs. calling the database through conventional (PHP) means. &#8220;You can do nice stuff like loading new content without a full page load,&#8221; he said. &#8220;And because of WP API’s internal reusability, you can also render it server side with practically the same code.&#8221; Others chimed in that lazy loading, AJAX calls, infinite scroll and the like will be much easier to implement with the new API.</p>
<p>&#8220;The biggest effect I think the REST API will have is in opening up this data to other developers, including plugin and theme developers,&#8221; McCue said. &#8220;We&#8217;re increasingly seeing more advanced front ends, including <a href="https://thethemefoundry.com/wordpress-themes/collections/" target="_blank">Theme Foundry&#8217;s Collections</a> theme, P2 and the upcoming o2, and sites like <a href="http://qz.com/" target="_blank">Quartz</a>, and WP API will enable these sorts of sites to be built much quicker.&#8221;</p>
<p>In the past, these sorts of projects were extraordinarily unique endeavors that required a great deal of effort to build. With the JSON REST API finally added to WordPress core, the platform will be more open to unique use cases.</p>
<p>&#8220;The API will enable front end developers to build themes on WordPress without needing to know PHP or many of WP&#8217;s quirks,&#8221; McCue said. <strong>&#8220;I believe it will really open up WordPress as a framework that&#8217;s easily accessible to everyone.&#8221;</strong> As the project stands today, the team is working towards making improvements that will ensure the API&#8217;s readiness for WordPress 4.1. If you have feedback to add from working with version 1.0 or would like to contribute to the project, join the WP API Team Tuesdays in the #wordpress-dev channel on IRC at 00:00 UTC.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 23:14:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WPTavern: WordPress.com Security Vulnerability Stirs Debate Over Responsible Disclosure";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23537";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:218:"http://wptavern.com/wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-com-security-vulnerability-stirs-debate-over-responsible-disclosure";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6809:"<p>Late last week, Yan Zhu, a Staff Technologist for the <a title="https://eff.org/" href="https://eff.org/">Electronic Frontier Foundation </a>publicly <a title="https://zyan.scripts.mit.edu/blog/wordpress-fail/" href="https://zyan.scripts.mit.edu/blog/wordpress-fail/">disclosed</a> a security vulnerability she discovered with WordPress.com and how it handles cookies. More specifically, she discovered the &#8220;<em>wordpress_logged_in</em>” cookie being sent in the clear to a WordPress authentication endpoint. She was able to use the authenticated cookie to publish blog posts, view private posts, post comments on others blogs, see their stats, and related administrative tasks that didn&#8217;t require logging in a second time.</p>
<div id="attachment_23609" class="wp-caption aligncenter"><a href="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/CookiesSecurityFeaturedImage.png" rel="prettyphoto[23537]"><img class="size-full wp-image-23609" src="http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/CookiesSecurityFeaturedImage.png?resize=640%2C249" alt="Cookies Security Featured Image" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/pedrovezini/5187327989/">Pedro Vezini</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-sa/2.0/">cc</a></p></div>
<p>Zhu contacted <a title="security@automattic.com" href="http://wptavern.com/security@automattic.com">security@automattic.com</a> and <a title="security@wordpress.org" href="http://wptavern.com/security@wordpress.org">security@wordpress.org</a> as the directions say to within the <a title="http://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/#where-do-i-report-security-issues." href="http://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/#where-do-i-report-security-issues.">WordPress core handbook</a>. Within 24 hours of notifying Automattic, Zhu publicly disclosed the vulnerability on her blog. The information was picked up by <a title="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/" href="http://arstechnica.com/security/2014/05/unsafe-cookies-leave-wordpress-accounts-open-to-hijacking-2-factor-bypass/">Ars Technica</a> resulting in millions of readers finding out about the security issue before a fix was available. What was once a good deed is now an example of irresponsible disclosure.</p>
<p>According to Wikipedia, <a title="http://en.wikipedia.org/wiki/Responsible_disclosure" href="http://en.wikipedia.org/wiki/Responsible_disclosure">responsible disclosure</a> is defined as:</p>
<blockquote><p>A <a title="Computer security" href="http://en.wikipedia.org/wiki/Computer_security">computer security</a> term describing a <a class="mw-redirect" title="Vulnerability disclosure" href="http://en.wikipedia.org/wiki/Vulnerability_disclosure">vulnerability disclosure</a> model. It is like <a title="Full disclosure (computer security)" href="http://en.wikipedia.org/wiki/Full_disclosure_%28computer_security%29">full disclosure</a>, with the addition that all stakeholders agree to allow a period of time for the <a title="Vulnerability (computing)" href="http://en.wikipedia.org/wiki/Vulnerability_%28computing%29">vulnerability</a> to be <a title="Patch (computing)" href="http://en.wikipedia.org/wiki/Patch_%28computing%29">patched</a> before publishing the details. Developers of hardware and software often require time and resources to repair their mistakes.</p></blockquote>
<p>When <a title="https://zyan.scripts.mit.edu/blog/wordpress-fail/#comment-70" href="https://zyan.scripts.mit.edu/blog/wordpress-fail/#comment-70">asked</a> why she didn&#8217;t give Automattic more time, Zhu responded:</p>
<blockquote><p>However, in this case, I believe that 24hrs was a fair amount of time. The main reason is that SSL support nowadays is widely accepted as the bare *minimum* security guarantee that a website should provide for users’ private information, and this is essentially a bug in WordPress’s SSL support. “Only send auth info over SSL” has been the most basic security recommendation to website operators for the last 15+ years.</p></blockquote>
<p>Although <a title="http://automattic.com/security/" href="http://automattic.com/security/">Automattic states</a> they&#8217;ll try to contact the reporter within 24 hours, I&#8217;d give them at least 72. The WordPress core handbook states that <strong>in all cases, you should not publish the details</strong>. The Automattic submission form states, &#8220;If you happen to find a <strong>security vulnerability</strong> in one of our services, we would appreciate letting us know before disclosing the issue publicly.&#8221; Perhaps the Automattic submission form should also request that reporters not publish the details.</p>
<h3>When Disclosure Becomes Irresponsible</h3>
<p>Any time a security vulnerability is disclosed before it&#8217;s fixed within a reasonable time frame, it&#8217;s irresponsible disclosure. Of course, what is a reasonable time frame is subjective but common sense dictates at least 3-5 days to hear a response back. Besides, they have to verify and duplicate the report in order to come up with a fix. Even if the issue is already known to attackers or is easy to find, it doesn&#8217;t make it <strong>ok</strong> to publicize it through the media. These types of actions fan the flames and make the reporter look like the bad person.</p>
<p>When it comes to how long of a time frame is acceptable before going to the public, everyone likely has a different answer. It also depends on what has gone on behind the scenes. For instance, when was it reported and when did the company respond back? Did they promise a fix but haven&#8217;t released it in months? In rare instances, publicizing a vulnerability is the only way to get a company to act but should be treated as the nuclear option.</p>
<p>In the comments of Zhu&#8217;s article, <a title="https://zyan.scripts.mit.edu/blog/wordpress-fail/#comment-106" href="https://zyan.scripts.mit.edu/blog/wordpress-fail/#comment-106">Matt Mullenweg thanked her</a> for the report with a request that she allow more time for Automattic to act.</p>
<blockquote><p>Thank you very much for finding and investigating this problem. If there’s a next time, I would definitely appreciate it if you gave us a few days more next time to protect users before it’s public.</p></blockquote>
<p>Do you think Zhu is in the wrong for publishing details of the security issue too soon or was 24 hours enough time for Automattic to implement a fix? If you discovered a security vulnerability and reported it to the vendor, what would need to happen to convince you that publicizing is the only way to get it fixed?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 19:46:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Matt: New Socket.IO 1.0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43826";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:39:"http://ma.tt/2014/05/new-socket-io-1-0/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:225:"<p><a href="http://socket.io/blog/introducing-socket-io-1-0/#credits">Socket.IO 1.0 is available</a> with a number of new features, including binary support. Socket.IO is one of the most useful tools in the Node.js world.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 19:16:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: How to Set Up Text Message Alerts for a WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=22934";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:160:"http://wptavern.com/how-to-set-up-text-message-alerts-for-a-wordcamp?utm_source=rss&utm_medium=rss&utm_campaign=how-to-set-up-text-message-alerts-for-a-wordcamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3885:"<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/text-alerts.jpg" rel="prettyphoto[22934]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/text-alerts.jpg?resize=832%2C356" alt="text-alerts" class="aligncenter size-full wp-image-23634" /></a></p>
<p><a href="http://wptavern.com/recap-of-wordcamp-miami-2014" target="_blank">WordCamp Miami</a> is one of the largest WordPress events in operation, with 770+ attendees and a large group of organizers and volunteers who turned out for its most recent 5th anniversary edition. It ran earlier this month with four days (Thursday &#8211; Sunday) packed full of activities. Multiple venues, parking areas, presentation tracks, catering and food vendors can all add to the likelihood of unexpected delays or changes in schedule.</p>
<p>How do you keep that many people informed with updates? Text alerts were the glue that kept everyone together on the same page, according to organizer <a href="https://twitter.com/dimensionmedia/" target="_blank">David Bisset</a>. WordCamp Miami utilized <a href="https://gather.mailchimpapp.com/" target="_blank">MailChimp&#8217;s Gather service</a> to shoot out reminders and changes of schedule.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/gather-text-update.jpg" rel="prettyphoto[22934]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/gather-text-update.jpg?resize=296%2C516" alt="gather-text-update" class="alignright size-full wp-image-23647" /></a>Many WordCamps use MailChimp to organize event emails. The Gather app allows you to text message your MailChimp email subscribers to keep them updated throughout the event. Subscribers can respond to organizers individually with no app or setup required. For example, if you want to alert everyone where parking is located, you can send a quick text in the morning. Attendees can also alert you to any problems.</p>
<p>When you set up a new event with Gather, it gives you a customizable signup form that you can share via Twitter, email or your MailChimp account. It also gives you a phone number to use that is separate from your personal number, so you can retain your privacy. The organizer never has access to subscribers&#8217; phone numbers and the service automatically deletes the numbers after the event expires.</p>
<p>Pricing is a nominal fee that you pre-pay for bundles of text messages, depending on the size of your event: 175 messages for $8.99, 500 messages for $18.99, or 2000 messages for $48.99. This includes your new Gather phone number.</p>
<h3>Getting Attendees to Sign Up For Text Alerts</h3>
<p>Getting people to sign up for text alerts may not be the easiest task, as nobody wants to open up their phone to a flood of unimportant messages or info that&#8217;s already printed in the schedule.</p>
<p>It&#8217;s a good idea to assure your subscribers that you&#8217;re not going to overload them with texts. Make sure they know their numbers will be deleted after the event and that you&#8217;ll send only the important stuff. WordCamp Miami did a good job of this on its text alerts signup page:</p>
<blockquote><p>We will keep the notifications to a minimum. They will involve any last-minute session/room changes, after party information, and emergency information.</p></blockquote>
<p>Bisset had three separate text message channels for the event, including one for general attendees, volunteer corps, and WordCamp organizers. He said that it kept their team from having to run around and holler at each other for help during the event.</p>
<p>As an attendee and speaker at WordCamp Miami, I can attest to the fact that these text message alerts kept everything running like a well-oiled machine. I would highly recommend them to any organizer who is looking to improve the overall event experience for attendees and volunteers.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 19:08:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WordPress.tv: Alexandre Simard: Débutant III – Louer, acheter ou changer de quartier?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33497";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/05/28/alexandre-simard-debutant-iii-louer-acheter-ou-changer-de-quartier/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:724:"<div id="v-TrAFJDeG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33497/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33497/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33497&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/28/alexandre-simard-debutant-iii-louer-acheter-ou-changer-de-quartier/"><img alt="Alexandre Simard: Débutant III – Louer, acheter ou changer de quartier?" src="http://videos.videopress.com/TrAFJDeG/video-7814b3e6fc_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 13:00:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress.tv: Kaylynne Johnson: Débutant II – La gestion des médias dans WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33474";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wordpress.tv/2014/05/28/kaylynne-johnson-debutant-ii-la-gestion-des-medias-dans-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:715:"<div id="v-GWljzl81-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33474/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33474/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33474&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/28/kaylynne-johnson-debutant-ii-la-gestion-des-medias-dans-wordpress/"><img alt="Kaylynne Johnson: Débutant II – La gestion des médias dans WordPress" src="http://videos.videopress.com/GWljzl81/video-ade276d4b9_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 12:40:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:89:"WordPress.tv: Élise Desaulniers: Débutant I – WordPress.com: le tour du propriétaire";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=33465";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2014/05/28/elise-desaulniers-debutant-i-wordpress-com-le-tour-du-proprietaire/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:719:"<div id="v-6M4JadgG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/33465/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/33465/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=33465&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/28/elise-desaulniers-debutant-i-wordpress-com-le-tour-du-proprietaire/"><img alt="Élise Desaulniers: Débutant I – WordPress.com: le tour du propriétaire" src="http://videos.videopress.com/6M4JadgG/video-f481529909_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 12:20:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WordPress.tv: Peter Nemčok: Slobodný softvér, slobodná firma";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35166";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2014/05/28/peter-nemcok-slobodny-softver-slobodna-firma/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-BOZExuOn-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35166/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35166/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35166&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/28/peter-nemcok-slobodny-softver-slobodna-firma/"><img alt="5. Peter Nemcok.avi" src="http://videos.videopress.com/BOZExuOn/video-b99c20bbc1_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 12:00:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WPTavern: WordPress Celebrates Its 11th Birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23512";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:140:"http://wptavern.com/wordpress-celebrates-its-11th-birthday?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-celebrates-its-11th-birthday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2548:"<div id="attachment_23622" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/birthday.jpg" rel="prettyphoto[23512]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/birthday.jpg?resize=1023%2C561" alt="photo credit: A30_Tsitika - cc" class="size-full wp-image-23622" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/frozen-in-time/2263904827/">A30_Tsitika</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>Today marks 11 years since the very <a href="http://wordpress.org/news/2003/05/wordpress-now-available/" target="_blank">first official public release of WordPress</a>. Reading through that <a href="http://codex.wordpress.org/Changelog/0.70" target="_blank">changelog</a> will make you smile and realize how far the software has come since the early days when its main competitors were <a href="http://www.textpattern.com/" target="_blank">Textpattern</a> and <a href="http://movabletype.org/" target="_blank">Movable Type</a>.</p>
<p>Fast forward 11 years and WordPress now powers <a href="http://w3techs.com/technologies/overview/content_management/all" target="_blank">22% of the web</a> with a content management system market share of 60.0%. Many moons ago, when you were hacking <a href="http://wordpress.org/themes/default" target="_blank">Kubrick</a>, did you ever imagine that you&#8217;d see WordPress <a href="http://wptavern.com/wordpress-for-ios-featured-in-apples-new-ipad-advertising-campaign" target="_blank">featured in an Apple product advertisement</a>? Could you have predicted that WordPress would power major news publications and government sites around the globe?</p>
<p>Over the past decade, this open source platform has enabled people to build creative, thriving businesses that support their families and improve the lives of others in small and big ways. With more than 31,000 free <a href="http://wordpress.org/plugins/" target="_blank">plugins</a> and 665 million plugin downloads, WordPress&#8217; extensibility makes it possible for the platform to power nearly any kind of website, from major corporations to universities to social networks. Best of all, WordPress has helped ordinary people tell their stories and find a voice in the world.</p>
<p>Here&#8217;s to the people who build WordPress, the ever-growing community that supports it, and the users who choose to publish with it every day. Happy birthday and congratulations on 11 years burning brighter.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 05:00:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: WordPress for iOS Featured in Apple’s New iPad Advertising Campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23507";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:196:"http://wptavern.com/wordpress-for-ios-featured-in-apples-new-ipad-advertising-campaign?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-for-ios-featured-in-apples-new-ipad-advertising-campaign";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2437:"<p>Apple has a new advertisement for iPad, featuring Chérie King, whose WordPress-powered <a href="http://flightofthetravelbee.com/" target="_blank">Flight of the Travel Bee</a> blog is dedicated to helping deaf people discover the joy of traveling.</p>
<p>Her story can be found at <a href="http://www.apple.com/cherie" target="_blank">apple.com/cherie</a> and is included as part of the &#8220;<a href="http://www.apple.com/your-verse/" target="_blank">What will your verse be?</a>&#8221; campaign. The first video beautifully captures Chérie&#8217;s love of traveling and shows her blogging on the go using the <a href="http://wpiphone.wordpress.com/" target="_blank">WordPress for iOS</a> app.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-on-ipad.jpg" rel="prettyphoto[23507]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-on-ipad.jpg?resize=1025%2C835" alt="wp-on-ipad" class="aligncenter size-full wp-image-23581" /></a></p>
<p>Chérie uses her iPad to help her navigate the world and connect with others on her travels. The campaign features WordPress among her top apps for documenting her international adventures. She uses the mobile app to publish photos and updates to her self-hosted WordPress site.</p>
<p><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/cherie-apps.jpg" rel="prettyphoto[23507]"><img src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/cherie-apps.jpg?resize=722%2C416" alt="cherie-apps" class="aligncenter size-full wp-image-23587" /></a></p>
<p>An interactive map on <a href="http://flightofthetravelbee.com/" target="_blank">Flight of the Travel Bee</a> leads to archives for posts from her visits to 31 countries. Each destination from her travels has its own category. The site makes use of a few popular plugins, including WordPress SEO by Yoast, Contact Form 7 and W3 Total Cache.</p>
<p>It&#8217;s inspiring to see that the WordPress publishing experience on mobile has improved to the point where it&#8217;s featured among other top iOS apps as a solid go-to for sharing experiences. Apple is well known for its inspiring product advertisements and <a href="http://www.apple.com/cherie" target="_blank">Chérie King&#8217;s videos</a> are particularly engaging. Her story is a beautiful example of WordPress at its finest &#8211; helping people tell their stories and create digital footprints along the way.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 28 May 2014 00:26:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: bbPress 2014 Survey Results Show Users Are Still Disappointed with Lack of Features";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23441";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:230:"http://wptavern.com/bbpress-2014-survey-results-show-users-are-still-disappointed-with-lack-of-features?utm_source=rss&utm_medium=rss&utm_campaign=bbpress-2014-survey-results-show-users-are-still-disappointed-with-lack-of-features";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8918:"<p>The results of the 2014 bbPress survey are <a title="https://bbpress.org/blog/2014/05/2014-bbpress-survey-results/" href="https://bbpress.org/blog/2014/05/2014-bbpress-survey-results/">now available</a>. The survey was conducted between March 7 – April 11, 2014. 183 people from 37 countries participated. The survey gave users a chance to give feedback and shape the direction of bbPress development throughout 2014.</p>
<p>A common complaint I often hear is the lack of documentation and articles within the <a title="http://codex.bbpress.org/" href="http://codex.bbpress.org/">bbPress Codex</a>. 73% of respondents said they did not contribute to bbPress development. Out of those who have contributed to the project, only 7% have written articles for the Codex.</p>
<div id="attachment_23562" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/ContributedTobbPress.png" rel="prettyphoto[23441]"><img class="size-full wp-image-23562" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/ContributedTobbPress.png?resize=592%2C823" alt="bbPress Codex Articles Are Hard To Come By" /></a><p class="wp-caption-text">bbPress Codex Articles Are Hard To Come By</p></div>
<p>It probably doesn&#8217;t help that in order to log into the bbPress.org website, you need to log into BuddyPress.org first. Then after you login, you&#8217;re not redirected to bbPress.org, you&#8217;re stuck on BuddyPress.org. If newcomers are looking to contribute to the Codex, you won&#8217;t be able to learn how because the <a title="http://codex.bbpress.org/participate-and-contribute/codex-standards-guidelines/" href="http://codex.bbpress.org/participate-and-contribute/codex-standards-guidelines/">Codex Standards and Guidelines</a> document links to a 404 error page.</p>
<p>When asked what are the strengths of bbPress, the top four answers are what I&#8217;d expect. It&#8217;s free, open source, is an official plugin, and easily integrates with WordPress and BuddyPress.</p>
<div id="attachment_23565" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/bbPressTopFourStrengths.png" rel="prettyphoto[23441]"><img class="size-full wp-image-23565" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/bbPressTopFourStrengths.png?resize=607%2C541" alt="Top Four Strengths Of bbPress" /></a><p class="wp-caption-text">Top Four Strengths Of bbPress</p></div>
<p>When asked what are the weaknesses to bbPress, the answers don&#8217;t surprise me. In fact, it&#8217;s the same set of complaints I&#8217;ve read and heard over the past few years. It lacks features out of the box compared to other forum software which leads to using several plugins just to bring it up to par. What surprises me most is that 54% said they were not sure about the future of the plugin.</p>
<div id="attachment_23566" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/bbPressUncertainFuture.png" rel="prettyphoto[23441]"><img class="size-full wp-image-23566" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/bbPressUncertainFuture.png?resize=581%2C375" alt="Uncertain Of The Future Of bbPress" /></a><p class="wp-caption-text">Uncertain Of The Future Of bbPress</p></div>
<p>It&#8217;s been <a title="https://bbpress.trac.wordpress.org/changeset/2463" href="https://bbpress.trac.wordpress.org/changeset/2463">four years</a> since bbPress switched from being a stand alone piece of software to a WordPress plugin. There was <a title="http://bbpress.org/forums/topic/bbpress-plugin-is-born/" href="http://bbpress.org/forums/topic/bbpress-plugin-is-born/">a lot of uncertainty</a> about the project around the time of the switch but that was four years ago. I&#8217;m curious as to why 54% of respondents are not sure about the future of the plugin. In those four years, John James Jacoby, Stephen Edgar, and several other contributors have made substantial improvements to the plugin. How could those improvements lead to uncertainty?</p>
<p>The requested improvements and new features list are similar to the list of most popular bbPress plugins activated. While attachments took the top spot with 42%, most of the votes were evenly distributed. This leads me to believe users would like to see every feature in the list added to bbPress. Take a look at the list of features and tell me which are not already available in most forum software.</p>
<div id="attachment_23567" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/TopRequestedItems.png" rel="prettyphoto[23441]"><img class="size-full wp-image-23567" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/TopRequestedItems.png?resize=482%2C621" alt="Top Requested bbPress Features" /></a><p class="wp-caption-text">Top Requested bbPress Features</p></div>
<p>88% of respondents said they evaluated other forum software before deciding on bbPress. Of those evaluated, phpBB took the top spot with 72%. The SimplePress plugin took second place with 44%. Despite its lack of features out of the box, bbPress was chosen by many of the respondents over other popular forum software. Considering the price tag on vBulletin, I was surprised it ranked so high.</p>
<div id="attachment_23568" class="wp-caption aligncenter"><a href="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/OtherForumSoftwareEvaluated.png" rel="prettyphoto[23441]"><img class="size-full wp-image-23568" src="http://i0.wp.com/wptavern.com/wp-content/uploads/2014/05/OtherForumSoftwareEvaluated.png?resize=579%2C369" alt="Other Forum Software Evaluated" /></a><p class="wp-caption-text">Other Forum Software Evaluated</p></div>
<h3>bbPress Has Come A Long Way But Has So Much Further To Go</h3>
<p>In 2009, I <a title="http://wptavern.com/why-i-use-vbulletin" href="http://wptavern.com/why-i-use-vbulletin">explained why</a> I chose vBulletin over bbPress to power the WP Tavern forum. Many of the reasons in that post are still valid arguments for why I&#8217;d probably not use bbPress today. It makes me sad to see so many huge walls in front of the bbPress project. As an end-user, the lack of features in bbPress is a detriment, not a feature itself. The code that makes up bbPress is some of the best you&#8217;ll see in a WordPress plugin but great code doesn&#8217;t equate to mainstream use.</p>
<p>bbPress has a lot going for it. It&#8217;s a WordPress plugin so it works with WordPress as if they are one entity and being a plugin, it&#8217;s simple to install. The default theme compatibility enables it to blend in with just about every WordPress theme. It&#8217;s free, open source, and considered an official plugin and there&#8217;s a passionate community supporting it.</p>
<p>If bbPress is ever going to be on par with other forum solutions, it&#8217;s going to have to pack more punch into its default feature set. I&#8217;m not the only who thinks so. Take this survey comment for example:</p>
<blockquote><p>Needs a lot more focus on adding front end features both for users and mods/admins. There is a serious lack of traditional forum features that people expect to have, and it really holds bbPress back.</p></blockquote>
<p>I think users would love to have something that suits most of their needs out of the box and then add plugins for additional functionality. Unfortunately, bbPress requires several plugins to be installed before it can even be considered on par with its competition.</p>
<h3>Will bbPress Ever Be Mainstream?</h3>
<p>There are other forces at work besides what is going on internally with bbPress. The nature of social interaction on the web is radically different from 10 years ago. Forums were like watering holes for specific topics with like-minded individuals. Today, most of the conversation happens on one or more social networks. There is also an <a title="http://www.businessesgrow.com/2014/03/26/eliminating-comments/" href="http://www.businessesgrow.com/2014/03/26/eliminating-comments/">ongoing trend</a> of large websites turning comments off.</p>
<p>One of the <a title="http://bbpress.org/blog/2013/11/bbpress-2-5-released/" href="http://bbpress.org/blog/2013/11/bbpress-2-5-released/">signature features of bbPress 2.6</a> will replace WordPress comments with bbPress topics. You&#8217;ll be able to replace your comment form with bbPress and merge together community conversations that forums provide with directed topics of conversation via the blog. It&#8217;s a marriage of functionality I&#8217;ve been wanting for years but it might be too little too late.</p>
<p>Will this feature spark a renaissance of forums, community, and on site conversations or has managing such things become too much work? Will we ever see the day when the percentage of sites using bbPress is as closely monitored as that of sites using WordPress?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 27 May 2014 23:00:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Jeff Chandler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: WordPress JSON REST API Version 1.0 Released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=23496";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:152:"http://wptavern.com/wordpress-json-rest-api-version-1-0-released?utm_source=rss&utm_medium=rss&utm_campaign=wordpress-json-rest-api-version-1-0-released";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4946:"<p>Version 1.0 of the <a href="http://wordpress.org/plugins/json-rest-api/" target="_blank">JSON REST API plugin</a> was <a href="http://make.wordpress.org/core/2014/05/25/json-rest-api-version-1-0/" target="_blank">released</a> over the weekend, adding new user, revision and post meta endpoints. This release also introduces the project&#8217;s new long-term backwards compatibility policy for its internal PHP API and REST API, which will not be broken from this point forward as new endpoints and data are added.</p>
<p>The WP API project is led by <a href="https://twitter.com/rmccue" target="_blank">Ryan McCue</a>, who said that the team is pushing hard for integration into WordPress 4.0, although it is not yet guaranteed. McCue published an <a href="https://gist.github.com/rmccue/722769379f4fc4148b1f" target="_blank">integration plan</a> for getting the WP API into core for the 4.0 merge window, if the project receives the green light.</p>
<h4>Understanding the Benefits of the JSON REST API</h4>
<p>McCue&#8217;s proposal highlights the need for an alternative to the XML-RPC API that is currently provided in core and demonstrates how the JSON REST API provides a superior solution for allowing remote access to data.</p>
<p>Because the WP API was designed from the ground up for integration into WordPress, it follows WP coding standards and will enter the core with full translatability. The WP API is being built to eventually include every data type found in WordPress, including post types and their metadata. It&#8217;s also built with extensibility in mind for themes and plugins and makes liberal use of actions and filters.</p>
<p>In addition to the huge benefit of the API being built <strong>FOR</strong> WordPress, McCue sites several other distinct benefits to its inclusion in core, including:</p>
<ul>
<li>Data serialization uses the JSON standard, which maps more directly to common data structures in most programming languages.</li>
<li>Communication with the API uses the HTTP 1.1 standard, available in almost every programming language. Representational State Transfer (&#8220;REST&#8221;) semantics are used for interaction, which are available in the majority of HTTP clients, and compatibility is provided for those without this ability.</li>
<li>The data serialization layer is independent of the data manipulation and accessing layer, enabling the JSON or HTTP semantics to be replaced with another protocol, (i.e. MessagePack or Cap&#8217;n Proto.)</li>
<li>The internal structure of the API allows use by regular PHP code. This enables using the data layer of the API for other uses, such as a future version of WP-CLI or internal form handlers.</li>
</li>
<li>The API relies on no external services. It includes methods for automatically locating the API given only a WordPress site address, as well as programatically assessing the availability of parts of the API.</li>
</ul>
<h4>WordPress Developers are Already Building API Plugins</h4>
<p>This API constitutes a monolithic addition to the WordPress codebase but it opens up a whole new world for developers who are extending the platform to access information remotely. Shortly after version 1.0 was released, a few WordPress developers reported back about making use of the API in their projects.</p>
<p><a href="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/bp-json-api.jpg" rel="prettyphoto[23496]"><img src="http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/bp-json-api.jpg?resize=226%2C219" alt="bp-json-api" class="alignright size-full wp-image-23526" /></a>Ryan Fugate (@modemlooper), took the initiative to add <a href="https://github.com/modemlooper/buddypress-json-api" target="_blank">BuddyPress JSON API</a> endpoints. When Scott Kingsley Clark saw the starter scaffolding for the BuddyPress API, he was inspired to build a <a href="https://github.com/pods-framework/pods-json-api" target="_blank">Pods JSON API</a> for his <a href="http://pods.io/" target="_blank">Pods Framework</a> in just a few short hours.</p>
<p>McCue and his team of contributors are now starting on a documentation and testing push to prepare the plugin for possible inclusion into WordPress 4.0. A documentation site is now up at <a href="http://wp-api.github.io/" target="_blank">wp-api.github.io</a>. These docs are very much in transition as the project moves forward and will eventually include the <a href="https://github.com/WP-API/WP-API/tree/master/docs/guides" target="_blank">guides</a> and master <a href="https://github.com/WP-API/WP-API/tree/master/docs" target="_blank">docs</a> which are in different places right now. If you&#8217;d like to jump in on some <a href="https://gist.github.com/rmccue/722769379f4fc4148b1f#open-issues" target="_blank">open issues</a> or help with the WP API project, the team welcomes new contributors on its <a href="http://wpapiteam.wordpress.com/" target="_blank">O2 development blog</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 27 May 2014 18:53:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: Nestor Romero: SEO en WordPress – La gran revolución";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25193";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://wordpress.tv/2014/05/27/nestor-romero-seo-en-wordpress-la-gran-revolucion/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:692:"<div id="v-uwG3XfA6-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25193/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25193/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25193&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/27/nestor-romero-seo-en-wordpress-la-gran-revolucion/"><img alt="Nestor Romero: SEO en WordPress &#8211; La gran revolución" src="http://videos.videopress.com/uwG3XfA6/video-3cc4922479_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 27 May 2014 08:00:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Camino García: WordPress – Aspectos legales";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25244";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2014/05/27/camino-garcia-wordpress-aspectos-legales/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:674:"<div id="v-uq1eyCpu-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25244/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25244/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25244&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/27/camino-garcia-wordpress-aspectos-legales/"><img alt="Camino García: WordPress &#8211; Aspectos legales" src="http://videos.videopress.com/uq1eyCpu/video-3ad9bf484c_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 27 May 2014 07:00:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Amit Kvint: Manejo y creación de una web multilingüe con WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25246";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wordpress.tv/2014/05/26/amit-kvint-manejo-y-creacion-de-una-web-multilingue-con-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:717:"<div id="v-DSakR3R4-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25246/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25246/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25246&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/26/amit-kvint-manejo-y-creacion-de-una-web-multilingue-con-wordpress/"><img alt="Amit Kvint: Manejo y creación de una web multilingüe con WordPress" src="http://videos.videopress.com/DSakR3R4/video-b4dfc0c886_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 26 May 2014 22:08:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:98:"Matt: Seoul, Jakarta, Singapore, Tokyo, Osaka, Manila, Melbourne, Sydney, Wellington, and Auckland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43822";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:33:"http://ma.tt/2014/05/summer-tour/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2474:"<p>Later this week I&#8217;m heading on a speaking tour of a number of cities in Asia, Australia, and New Zealand talking about the past and future of WordPress and some of the things I&#8217;ve learned in the past few years of building <a href="http://wordpress.org/">WordPress</a> and <a href="http://automattic.com/">Automattic</a>. It&#8217;s been a number of years since I&#8217;ve visited these countries, and I&#8217;ve never been to Korea, Singapore, Melbourne, or Auckland before, so really looking forward to meeting the local communities in each of these cities and learning about how we can best set up WordPress for the coming decade of growth, especially in languages other than English.</p>
<p>If you&#8217;re near any of these cities and want to come by check out the following links for more information. Even if it says &#8220;sold out&#8221; already, as many are, put your name on the waitlist anyway because I know some places are already searching for larger venues, and there could always be cancellations or spaces open up at the last minute.</p>
<p>Asia</p>
<ul class="ul1">
<li><a href="http://onoffmix.com/event/27342">Sunday, June 1: Seoul, South Korea</a></li>
<li><a href="http://wpjkt.org/blog/2014/05/09/3rd-jakarta-wordpress-meetup-with-matt-mullenweg-monday-june-2-2014/">Monday, June 2: Jakarta, Indonesia</a></li>
<li><a href="https://www.eventbrite.com/e/matt-mullenweg-live-tickets-3836477006">Wednesday, June 4: Singapore (info)</a></li>
<li><a href="http://wbtokyo.doorkeeper.jp/events/11074">Friday, June 6: Tokyo, Japan</a></li>
<li><a href="http://2014.kansai.wordcamp.org/outline/">Saturday, June 7: Osaka, Japan</a></li>
<li><a href="http://wpmeetup.wordpress.com/2014/05/06/wordpress-community-meetup-with-matt/">Monday, June 9: Manila, Philippines</a></li>
</ul>
<p>Australia &amp; New Zealand</p>
<ul>
<li class="li1"><a href="http://matt-mullenweg-melbourne.eventbrite.com.au/">Thursday, June 12: Melbourne</a></li>
<li class="li1"><a href="http://matt-mullenweg-sydney.eventbrite.com.au/">Monday, June 16: Sydney</a></li>
<li><a href="https://matt-mullenweg-wellington.eventbrite.com/">Tuesday, June 17: Wellington</a></li>
<li><a href="http://www.meetup.com/Auckland-WordPress-Users/events/183863442/">Wednesday, June 18: Auckland</a></li>
</ul>
<p>The schedule might be a little exhausting, but I wanted to make it as many communities as possible in the short window of time I have before I need to be stateside again.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 26 May 2014 19:19:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv: Tom Tortorici: Using Your Website To Engage Persuade And Sell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35191";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.tv/2014/05/26/tom-tortorici-using-your-website-to-engage-persuade-and-sell/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:699:"<div id="v-IYaQ6lYL-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35191/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35191/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35191&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/26/tom-tortorici-using-your-website-to-engage-persuade-and-sell/"><img alt="Tom Tortorici: Using Your Website To Engage Persuade And Sell" src="http://videos.videopress.com/IYaQ6lYL/video-c56941465a_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 26 May 2014 18:49:13 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Jason Swenk: The Smarter You Get The Less Money You Make. Why?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35194";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wordpress.tv/2014/05/26/jason-swenk-the-smarter-you-get-the-less-money-you-make-why/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:699:"<div id="v-H83Ir29Q-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35194/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35194/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35194&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/26/jason-swenk-the-smarter-you-get-the-less-money-you-make-why/"><img alt="Jason Swenk: The Smarter You Get The Less Money You Make. Why?" src="http://videos.videopress.com/H83Ir29Q/video-5c0872847c_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 26 May 2014 18:39:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WordPress.tv: Carolyn Sonnek: We Can’t Read Your Mind :: How To Find Help For Your WordPress Problems";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=35027";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:116:"http://wordpress.tv/2014/05/25/carolyn-sonnek-we-cant-read-your-mind-how-to-find-help-for-your-wordpress-problems-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:757:"<div id="v-VcP94vsG-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/35027/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/35027/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=35027&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/25/carolyn-sonnek-we-cant-read-your-mind-how-to-find-help-for-your-wordpress-problems-3/"><img alt="Carolyn Sonnek: We Can’t Read Your Mind :: How To Find Help For Your WordPress Problems" src="http://videos.videopress.com/VcP94vsG/video-0f00c6369c_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 25 May 2014 18:36:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WordPress.tv: Mansoor Munib: Theme and Plugin Development In WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=34925";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2014/05/25/mansoor-munib-theme-and-plugin-development-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-QpGDf9Rf-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/34925/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/34925/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=34925&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2014/05/25/mansoor-munib-theme-and-plugin-development-in-wordpress/"><img alt="Mansoor Munib: Theme and Plugin Development In WordPress" src="http://videos.videopress.com/QpGDf9Rf/video-f1402b159e_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 25 May 2014 18:17:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 02 Jun 2014 10:46:07 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"154369";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Mon, 02 Jun 2014 10:30:15 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130911030210";}', 'no') ; 
INSERT INTO `worldcup_options` VALUES (119, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1401749168', 'no') ; 
INSERT INTO `worldcup_options` VALUES (120, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1401705968', 'no') ; 
INSERT INTO `worldcup_options` VALUES (121, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1401749169', 'no') ; 
INSERT INTO `worldcup_options` VALUES (122, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Jun 2014 10:21:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"MailPoet Newsletters";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wysija-newsletters/#post-32629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 02 Dec 2011 17:09:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32629@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Send newsletters, post notifications or autoresponders from WordPress easily, and beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"MailPoet Staff";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 10 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"iThemes Security (formerly Better WP Security)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"21738@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"The easiest, most effective way to secure WordPress in seconds.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12073@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 02 Jun 2014 10:46:09 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Mon, 02 Jun 2014 10:56:28 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Mon, 02 Jun 2014 10:21:28 +0000";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130911030210";}', 'no') ; 
INSERT INTO `worldcup_options` VALUES (123, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1401749169', 'no') ; 
INSERT INTO `worldcup_options` VALUES (124, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1401705969', 'no') ; 
INSERT INTO `worldcup_options` VALUES (125, '_transient_timeout_plugin_slugs', '1401792633', 'no') ; 
INSERT INTO `worldcup_options` VALUES (126, '_transient_plugin_slugs', 'a:13:{i:0;s:35:"admin-menu-tree-page-view/index.php";i:1;s:30:"advanced-custom-fields/acf.php";i:2;s:27:"acf-gallery/acf-gallery.php";i:3;s:29:"acf-repeater/acf-repeater.php";i:4;s:19:"akismet/akismet.php";i:5;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:6;s:47:"fitvids-for-wordpress/fitvids-for-wordpress.php";i:7;s:27:"mail-subscribe-list/sml.php";i:8;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:9;s:23:"respondjs/respondjs.php";i:10;s:29:"wangguard/wangguard-admin.php";i:11;s:24:"wordpress-seo/wp-seo.php";i:12;s:39:"backup-with-restore/backupwordpress.php";}', 'no') ; 
INSERT INTO `worldcup_options` VALUES (127, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1401749169', 'no') ; 
INSERT INTO `worldcup_options` VALUES (128, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2014/05/wordpress-3-9-1/\'>WordPress 3.9.1 Maintenance Release</a> <span class="rss-date">May 8, 2014</span><div class="rssSummary">After three weeks and more than 9 million downloads of WordPress 3.9, we’re pleased to announce that WordPress 3.9.1 is now available. This maintenance release fixes 34 bugs in 3.9, including numerous fixes for multisite networks, customizing widgets while previewing themes, and the updated visual editor. We’ve also made some improvements to the new audio/vi</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/06/02/benjamin-caubere-crear-un-plugin-con-el-modelo-freemium-en-wordpress/\' title=\'\'>WordPress.tv: Benjamin Caubère: Crear un plugin con el modelo Freemium en WordPress</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2014/06/02/mercedes-romero-albertocontador-org-wordpress-multisitio-multiidioma-y-red-social/\' title=\'\'>WordPress.tv: Mercedes Romero: AlbertoContador.org – WordPress multisitio, multiidioma y red social</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/10-new-free-wordpress-themes-from-may-2014?utm_source=rss&#038;utm_medium=rss&#038;utm_campaign=10-new-free-wordpress-themes-from-may-2014\' title=\'May was an excellent month for free WordPress themes landing in the official Themes Directory. Several dozen were approved and added to the directory last week in one sweep. We’ve hand-picked some of the best themes released in the month of May, all of which have undergone the rigorous review process conducted by the Theme Review Team. Grab a coffee or tea a\'>WPTavern: 10 New Free WordPress Themes From May 2014</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/woocommerce/\' class=\'dashboard-news-plugin-link\'>WooCommerce - excelling eCommerce</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=woocommerce&amp;_wpnonce=3cb02d0bec&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'WooCommerce - excelling eCommerce\'>Install</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `worldcup_options` VALUES (130, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (132, 'acf_version', '4.3.8', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (139, 'wpseo_titles', 'a:60:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:0:"";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:0:"";s:15:"title-404-wpseo";s:0:"";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:17:"noauthorship-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:17:"noauthorship-page";b:1;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:23:"noauthorship-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (140, 'wpseo', 'a:18:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:11:"ignore_tour";b:1;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:19:"tracking_popup_done";b:1;s:7:"version";s:7:"1.5.3.2";s:11:"alexaverify";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:15:"pinterestverify";s:0:"";s:12:"yandexverify";s:0:"";s:14:"yoast_tracking";b:0;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (141, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1401706218;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (142, 'current_theme', 'Foundation', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (143, 'theme_mods_Foundation', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (144, 'theme_switched', '', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (145, 'hmbkp_dropbox_settings', 'a:2:{s:7:"enabled";s:2:"no";s:12:"access_token";N;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (146, 'hmbkp_default_path', '/Applications/MAMP/htdocs/worldcup/wp-content/backupwordpress-a3244bccb2-backups', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (147, 'hmbkp_path', '/Applications/MAMP/htdocs/worldcup/wp-content/backupwordpress-a3244bccb2-backups', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (148, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (149, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (150, 'hmbkp_plugin_version', '1.0', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (153, 'rewrite_rules', 'a:70:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (154, '_transient_doing_cron', '1401792812.6777760982513427734375', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (156, '_site_transient_timeout_theme_roots', '1401794614', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (157, '_site_transient_theme_roots', 'a:1:{s:10:"Foundation";s:7:"/themes";}', 'yes') ; 
INSERT INTO `worldcup_options` VALUES (158, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1401792818;s:8:"response";a:1:{s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:7:"1.5.3.3";s:3:"url";s:43:"http://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:63:"http://downloads.wordpress.org/plugin/wordpress-seo.1.5.3.3.zip";}}s:12:"translations";a:0:{}}', 'yes') ;
#
# End of data contents of table worldcup_options
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_postmeta`
#

DROP TABLE IF EXISTS `worldcup_postmeta`;


#
# Table structure of table `worldcup_postmeta`
#

CREATE TABLE `worldcup_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_postmeta (5 records)
#
 
INSERT INTO `worldcup_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `worldcup_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `worldcup_postmeta` VALUES (3, 4, '_edit_lock', '1401716413:1') ; 
INSERT INTO `worldcup_postmeta` VALUES (4, 2, '_edit_lock', '1401727988:1') ; 
INSERT INTO `worldcup_postmeta` VALUES (5, 2, '_edit_last', '1') ;
#
# End of data contents of table worldcup_postmeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_posts`
#

DROP TABLE IF EXISTS `worldcup_posts`;


#
# Table structure of table `worldcup_posts`
#

CREATE TABLE `worldcup_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_posts (6 records)
#
 
INSERT INTO `worldcup_posts` VALUES (1, 1, '2014-06-02 10:45:45', '2014-06-02 10:45:45', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2014-06-02 10:45:45', '2014-06-02 10:45:45', '', 0, 'http://localhost:8888/worldcup/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `worldcup_posts` VALUES (2, 1, '2014-06-02 10:45:45', '2014-06-02 10:45:45', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/worldcup/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2014-06-02 16:24:45', '2014-06-02 16:24:45', '', 0, 'http://localhost:8888/worldcup/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `worldcup_posts` VALUES (3, 1, '2014-06-02 10:46:04', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-06-02 10:46:04', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/worldcup/?p=3', 0, 'post', '', 0) ; 
INSERT INTO `worldcup_posts` VALUES (4, 1, '2014-06-12 17:00:07', '2014-06-12 17:00:07', '', 'Brazil vs Croatia', '', 'future', 'open', 'open', '', 'brazil-vs-croatia', '', '', '2014-06-02 13:41:40', '2014-06-02 13:41:40', '', 0, 'http://localhost:8888/worldcup/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `worldcup_posts` VALUES (5, 1, '2014-06-02 13:41:40', '2014-06-02 13:41:40', '', 'Brazil vs Croatia', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2014-06-02 13:41:40', '2014-06-02 13:41:40', '', 4, 'http://localhost:8888/worldcup/?p=5', 0, 'revision', '', 0) ; 
INSERT INTO `worldcup_posts` VALUES (6, 1, '2014-06-02 16:24:45', '2014-06-02 16:24:45', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:
<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin\' caught in the rain.)</blockquote>
...or something like this:
<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>
As a new WordPress user, you should go to <a href="http://localhost:8888/worldcup/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Home', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-06-02 16:24:45', '2014-06-02 16:24:45', '', 2, 'http://localhost:8888/worldcup/2-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table worldcup_posts
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_sml`
#

DROP TABLE IF EXISTS `worldcup_sml`;


#
# Table structure of table `worldcup_sml`
#

CREATE TABLE `worldcup_sml` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `sml_name` varchar(200) NOT NULL,
  `sml_email` varchar(200) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table worldcup_sml (0 records)
#

#
# End of data contents of table worldcup_sml
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_term_relationships`
#

DROP TABLE IF EXISTS `worldcup_term_relationships`;


#
# Table structure of table `worldcup_term_relationships`
#

CREATE TABLE `worldcup_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_term_relationships (2 records)
#
 
INSERT INTO `worldcup_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `worldcup_term_relationships` VALUES (4, 1, 0) ;
#
# End of data contents of table worldcup_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_term_taxonomy`
#

DROP TABLE IF EXISTS `worldcup_term_taxonomy`;


#
# Table structure of table `worldcup_term_taxonomy`
#

CREATE TABLE `worldcup_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_term_taxonomy (1 records)
#
 
INSERT INTO `worldcup_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ;
#
# End of data contents of table worldcup_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_terms`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_terms`
#

DROP TABLE IF EXISTS `worldcup_terms`;


#
# Table structure of table `worldcup_terms`
#

CREATE TABLE `worldcup_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_terms (1 records)
#
 
INSERT INTO `worldcup_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ;
#
# End of data contents of table worldcup_terms
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_usermeta`
#

DROP TABLE IF EXISTS `worldcup_usermeta`;


#
# Table structure of table `worldcup_usermeta`
#

CREATE TABLE `worldcup_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_usermeta (17 records)
#
 
INSERT INTO `worldcup_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `worldcup_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `worldcup_usermeta` VALUES (3, 1, 'nickname', 'administrator') ; 
INSERT INTO `worldcup_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `worldcup_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `worldcup_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `worldcup_usermeta` VALUES (7, 1, 'admin_color', 'blue') ; 
INSERT INTO `worldcup_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `worldcup_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'false') ; 
INSERT INTO `worldcup_usermeta` VALUES (10, 1, 'worldcup_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `worldcup_usermeta` VALUES (11, 1, 'worldcup_user_level', '10') ; 
INSERT INTO `worldcup_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', 'wp350_media,wp360_revisions,wp360_locks,wp390_widgets') ; 
INSERT INTO `worldcup_usermeta` VALUES (13, 1, 'show_welcome_panel', '0') ; 
INSERT INTO `worldcup_usermeta` VALUES (14, 1, 'worldcup_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `worldcup_usermeta` VALUES (15, 1, '_yoast_wpseo_profile_updated', '1401706219') ; 
INSERT INTO `worldcup_usermeta` VALUES (16, 1, 'closedpostboxes_post', 'a:1:{i:0;s:10:"wpseo_meta";}') ; 
INSERT INTO `worldcup_usermeta` VALUES (17, 1, 'metaboxhidden_post', 'a:6:{i:0;s:11:"postexcerpt";i:1;s:13:"trackbacksdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:7:"slugdiv";i:5;s:9:"authordiv";}') ;
#
# End of data contents of table worldcup_usermeta
# --------------------------------------------------------

# WordPress : http://localhost:8888/worldcup MySQL database backup
#
# Generated: Tuesday 3. June 2014 10:53 UTC
# Hostname: localhost
# Database: `worldcup`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_sml`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `worldcup_users`
# --------------------------------------------------------


#
# Delete any existing table `worldcup_users`
#

DROP TABLE IF EXISTS `worldcup_users`;


#
# Table structure of table `worldcup_users`
#

CREATE TABLE `worldcup_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table worldcup_users (1 records)
#
 
INSERT INTO `worldcup_users` VALUES (1, 'administrator', '$P$Bx4z7FoIE2i9FGq9jhxcDGhFpxhqq60', 'administrator', 'tom@fiascodesign.co.uk', '', '2014-06-02 10:45:45', '', 0, 'administrator') ;
#
# End of data contents of table worldcup_users
# --------------------------------------------------------

